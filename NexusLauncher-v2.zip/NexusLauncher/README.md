# Nexus Launcher 1.0.0 (build 1001)

Launcher Android (Kotlin, Views + AndroidX), Android 10+ (minSdk 29, targetSdk 34).

## Telas
- **Tela inicial:** relógio (digital, compacto, empilhado ou analógico), data, clima real (Open-Meteo), grade de favoritos (até 8), barra de pesquisa com voz, dock (3 apps padrão + botão da gaveta) e widgets do Android (opcional).
- **Gaveta:** pesquisa, abas (Tudo, Favoritos, Jogos, Redes, Ferramentas, suas categorias), grade, índice A–Z.
- **Configurações:** Aparência, Ícones, Widgets, Animações, Tela Inicial, Gaveta, Avançado e Sobre; com busca.

## Compilar
Android Studio: `Build > Build APK(s)`. Ou use o workflow `.github/workflows/build.yml` no GitHub.

## Observações
- Blur real (conteúdo e papel de parede) exige Android 12+.
- Clima: defina a cidade (toque no cartão de clima). Requer internet.
- Pacotes de ícones: padrão Nova/ADW/GO (`appfilter.xml`).
