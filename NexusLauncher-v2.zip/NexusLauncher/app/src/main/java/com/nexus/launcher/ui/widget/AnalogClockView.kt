package com.nexus.launcher.ui.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils
import java.util.Calendar

/** Relógio analógico minimalista, atualizado a cada segundo. */
class AnalogClockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var tint: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    var secondColor: Int = Color.WHITE
        set(v) { field = v; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 1000L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(tick)
        post(tick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 3f * d

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        paint.color = ColorUtils.setAlphaComponent(tint, 200)
        canvas.drawCircle(cx, cy, r, paint)

        for (i in 0 until 12) {
            canvas.save()
            canvas.rotate(i * 30f, cx, cy)
            val long = i % 3 == 0
            paint.strokeWidth = (if (long) 2f else 1f) * d
            paint.color = ColorUtils.setAlphaComponent(tint, if (long) 230 else 130)
            canvas.drawLine(cx, cy - r * (if (long) 0.84f else 0.9f), cx, cy - r * 0.96f, paint)
            canvas.restore()
        }

        val cal = Calendar.getInstance()
        val s = cal.get(Calendar.SECOND)
        val m = cal.get(Calendar.MINUTE) + s / 60f
        val h = (cal.get(Calendar.HOUR) % 12) + m / 60f

        paint.strokeCap = Paint.Cap.ROUND
        hand(canvas, cx, cy, h * 30f, r * 0.5f, 3.5f * d, tint)
        hand(canvas, cx, cy, m * 6f, r * 0.75f, 2.5f * d, tint)
        hand(canvas, cx, cy, s * 6f, r * 0.82f, 1.2f * d, secondColor)

        paint.style = Paint.Style.FILL
        paint.color = secondColor
        canvas.drawCircle(cx, cy, 3f * d, paint)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, angle: Float, len: Float, w: Float, color: Int) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = color
        c.save()
        c.rotate(angle, cx, cy)
        c.drawLine(cx, cy, cx, cy - len, paint)
        c.restore()
    }
}
