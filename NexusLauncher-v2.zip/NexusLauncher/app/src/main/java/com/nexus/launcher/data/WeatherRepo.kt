package com.nexus.launcher.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Clima real via Open-Meteo (gratuito, sem chave). A cidade é escolhida pelo usuário. */
object WeatherRepo {
    data class Info(val temp: Int, val code: Int, val place: String, val at: Long, val q: String)

    fun cached(p: Prefs): Info? {
        val s = p.sp.getString("weather_cache", null) ?: return null
        return try {
            val j = JSONObject(s)
            Info(j.getInt("t"), j.getInt("c"), j.getString("p"), j.getLong("a"), j.getString("q"))
        } catch (e: Exception) {
            null
        }
    }

    /** Bloqueante: chamar fora da thread principal. Retorna null se falhar. */
    fun refresh(p: Prefs): Info? {
        val city = p.weatherCity.trim()
        if (city.isEmpty()) return null
        return try {
            val sp = p.sp
            var lat = ""
            var lon = ""
            var place = ""
            if (sp.getString("w_q", "") == city && sp.contains("w_lat")) {
                lat = sp.getString("w_lat", "") ?: ""
                lon = sp.getString("w_lon", "") ?: ""
                place = sp.getString("w_place", city) ?: city
            } else {
                val geo = get(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" +
                        URLEncoder.encode(city, "UTF-8") + "&count=1&language=pt&format=json"
                ) ?: return null
                val results = JSONObject(geo).optJSONArray("results") ?: return null
                if (results.length() == 0) return null
                val r = results.getJSONObject(0)
                lat = r.getDouble("latitude").toString()
                lon = r.getDouble("longitude").toString()
                place = listOf(r.optString("name"), r.optString("admin1"))
                    .filter { it.isNotBlank() }.joinToString(", ")
                sp.edit().putString("w_q", city).putString("w_lat", lat)
                    .putString("w_lon", lon).putString("w_place", place).apply()
            }
            val fc = get(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&timezone=auto"
            ) ?: return null
            val cur = JSONObject(fc).getJSONObject("current")
            val info = Info(
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                cur.getInt("weather_code"),
                place,
                System.currentTimeMillis(),
                city
            )
            val j = JSONObject()
                .put("t", info.temp).put("c", info.code).put("p", info.place)
                .put("a", info.at).put("q", info.q)
            sp.edit().putString("weather_cache", j.toString()).apply()
            info
        } catch (e: Exception) {
            null
        }
    }

    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } finally {
            c.disconnect()
        }
    }

    /** Código WMO -> (emoji, descrição). */
    fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Céu limpo"
        1 -> "🌤️" to "Predominantemente limpo"
        2 -> "⛅" to "Parcialmente nublado"
        3 -> "☁️" to "Nublado"
        45, 48 -> "🌫️" to "Neblina"
        in 51..57 -> "🌦️" to "Garoa"
        in 61..67 -> "🌧️" to "Chuva"
        in 71..77, 85, 86 -> "❄️" to "Neve"
        in 80..82 -> "🌧️" to "Pancadas de chuva"
        in 95..99 -> "⛈️" to "Tempestade"
        else -> "🌡️" to "Tempo indefinido"
    }
}
