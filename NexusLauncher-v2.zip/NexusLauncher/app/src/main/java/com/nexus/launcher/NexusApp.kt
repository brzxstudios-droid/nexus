package com.nexus.launcher

import android.app.Application
import com.nexus.launcher.data.Prefs

class NexusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs(this).applyTheme()
    }
}
