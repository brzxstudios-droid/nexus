package com.nexus.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import java.text.Collator

/** Lista os apps lançáveis usando a API oficial do PackageManager. */
class AppRepository(private val ctx: Context) {
    fun load(): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val collator = Collator.getInstance().apply { strength = Collator.PRIMARY }
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                AppInfo(
                    it.loadLabel(pm).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .distinctBy { it.key }
            .sortedWith(Comparator<AppInfo> { a, b -> collator.compare(a.label, b.label) })
    }
}
