package com.nexus.launcher.data

import android.content.ComponentName
import com.nexus.launcher.util.normalized

data class AppInfo(val label: String, val component: ComponentName) {
    val key: String = component.flattenToString()
    val packageName: String get() = component.packageName
    val search: String = label.normalized()
}
