package com.nexus.launcher.settings

import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.nexus.launcher.R
import com.nexus.launcher.data.IconPackManager
import com.nexus.launcher.data.Prefs
import com.nexus.launcher.ui.home.HomeActivity
import com.nexus.launcher.util.Dialogs
import com.nexus.launcher.util.WallpaperHelper

abstract class SectionFragment : PreferenceFragmentCompat() {
    protected abstract val xml: Int
    protected abstract val title: String

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(xml, rootKey)
        onReady()
    }

    protected open fun onReady() {}

    override fun onResume() {
        super.onResume()
        requireActivity().title = title
    }

    protected fun pref(key: String): Preference? = findPreference(key)

    protected fun goHome(action: String) {
        startActivity(
            Intent(requireContext(), HomeActivity::class.java)
                .putExtra(HomeActivity.ACTION_KEY, action)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }
}

class RootFragment : SectionFragment() {
    override val xml = R.xml.prefs_root
    override val title = "Configurações do Nexus"
}

class AppearanceFragment : SectionFragment() {
    override val xml = R.xml.prefs_appearance
    override val title = "Aparência"

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) WallpaperHelper.set(requireContext(), uri)
    }

    override fun onReady() {
        pref("theme_mode")?.setOnPreferenceChangeListener { _, v ->
            Prefs(requireContext()).applyTheme(v as String)
            true
        }
        pref("pick_wallpaper")?.setOnPreferenceClickListener {
            picker.launch("image/*")
            true
        }
    }
}

class IconsFragment : SectionFragment() {
    override val xml = R.xml.prefs_icons
    override val title = "Ícones"

    override fun onReady() {
        val lp = pref("icon_pack") as? ListPreference ?: return
        val packs = IconPackManager(requireContext()).list()
        lp.entries = (listOf("Padrão do sistema") + packs.map { it.label }).toTypedArray<CharSequence>()
        lp.entryValues = (listOf("default") + packs.map { it.pkg }).toTypedArray<CharSequence>()
        if (lp.value == null) lp.value = "default"
        if (packs.isEmpty()) {
            lp.summary = "Nenhum pacote instalado (compatível com Nova, ADW e GO Launcher)"
        } else {
            lp.summaryProvider = ListPreference.SimpleSummaryProvider.getInstance()
        }
    }
}

class WidgetsFragment : SectionFragment() {
    override val xml = R.xml.prefs_widgets
    override val title = "Widgets"

    override fun onReady() {
        pref("add_widget")?.setOnPreferenceClickListener { goHome("add_widget"); true }
        pref("remove_widget")?.setOnPreferenceClickListener { goHome("remove_widget"); true }
    }
}

class AnimationsFragment : SectionFragment() {
    override val xml = R.xml.prefs_animations
    override val title = "Animações"
}

class HomeFragment : SectionFragment() {
    override val xml = R.xml.prefs_home
    override val title = "Tela inicial"
}

class DrawerFragment : SectionFragment() {
    override val xml = R.xml.prefs_drawer
    override val title = "Gaveta de aplicativos"

    override fun onReady() {
        pref("manage_categories")?.setOnPreferenceClickListener { manageCategories(); true }
    }

    private fun newCategory() {
        val p = Prefs(requireContext())
        Dialogs.promptText(requireContext(), "Nova categoria", "Nome da categoria") { p.addCategory(it) }
    }

    private fun manageCategories() {
        val ctx = requireContext()
        val p = Prefs(ctx)
        val cats = p.categories
        if (cats.isEmpty()) {
            newCategory()
            return
        }
        AlertDialog.Builder(ctx)
            .setTitle("Categorias (toque para excluir)")
            .setItems(cats.toTypedArray()) { _, i ->
                AlertDialog.Builder(ctx)
                    .setMessage("Excluir “${cats[i]}”? Os apps continuam instalados.")
                    .setPositiveButton("Excluir") { _, _ -> p.removeCategory(cats[i]) }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            .setPositiveButton("Nova") { _, _ -> newCategory() }
            .setNegativeButton("Fechar", null)
            .show()
    }
}

class AdvancedFragment : SectionFragment() {
    override val xml = R.xml.prefs_advanced
    override val title = "Personalização avançada"

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    override fun onReady() {
        pref("set_default")?.setOnPreferenceClickListener { requestDefaultHome(); true }
        pref("reset_favs")?.setOnPreferenceClickListener {
            confirm("Limpar todos os favoritos e categorias?") {
                Prefs(requireContext()).resetFavoritesAndCategories()
                Toast.makeText(requireContext(), "Favoritos e categorias limpos", Toast.LENGTH_SHORT).show()
            }
            true
        }
        pref("reset_all")?.setOnPreferenceClickListener {
            confirm("Restaurar todas as configurações e remover os widgets?") {
                Prefs(requireContext()).resetAll()
                Toast.makeText(requireContext(), "Configurações restauradas", Toast.LENGTH_SHORT).show()
                requireActivity().recreate()
            }
            true
        }
    }

    private fun confirm(msg: String, action: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setMessage(msg)
            .setPositiveButton("Confirmar") { _, _ -> action() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun requestDefaultHome() {
        val ctx = requireContext()
        val rm = ctx.getSystemService(RoleManager::class.java)
        try {
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    Toast.makeText(ctx, "O Nexus já é o launcher padrão", Toast.LENGTH_SHORT).show()
                } else {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                }
            } else {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
