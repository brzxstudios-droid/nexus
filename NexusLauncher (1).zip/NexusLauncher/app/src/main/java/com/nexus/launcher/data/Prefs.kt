package com.nexus.launcher.data

import android.appwidget.AppWidgetHost
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Acesso tipado às SharedPreferences. Os padrões aqui espelham os XMLs de configurações. */
class Prefs(context: Context) {
    private val ctx = context.applicationContext
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    companion object {
        const val WIDGET_HOST_ID = 1024
    }

    // Aparência
    val themeMode: String get() = sp.getString("theme_mode", "dark") ?: "dark"
    val accent: Int
        get() {
            val custom = sp.getString("accent_custom", "")?.trim().orEmpty()
            val hex = when {
                custom.isEmpty() -> sp.getString("accent", "#00E5FF") ?: "#00E5FF"
                custom.startsWith("#") -> custom
                else -> "#$custom"
            }
            return try {
                Color.parseColor(hex)
            } catch (e: IllegalArgumentException) {
                0xFF00E5FF.toInt()
            }
        }
    val panelAlpha: Int get() = sp.getInt("panel_alpha", 40)
    val blurRadius: Int get() = sp.getInt("blur_radius", 25)
    val wallpaperDim: Int get() = sp.getInt("wallpaper_dim", 30)

    // Ícones
    val iconSize: Int get() = sp.getInt("icon_size", 56)
    val iconShape: String get() = sp.getString("icon_shape", "original") ?: "original"
    val iconPack: String get() = sp.getString("icon_pack", "default") ?: "default"
    val showLabels: Boolean get() = sp.getBoolean("show_labels", true)

    // Animações
    val launchAnim: String get() = sp.getString("launch_anim", "zoom") ?: "zoom"
    val drawerAnim: String get() = sp.getString("drawer_anim", "slide") ?: "slide"
    val animSpeed: Int get() = sp.getInt("anim_speed", 100).coerceIn(50, 200)
    val pressScale: Boolean get() = sp.getBoolean("press_scale", true)
    val blurTransitions: Boolean get() = sp.getBoolean("blur_transitions", true)

    // Tela inicial
    val clock24: Boolean get() = sp.getBoolean("clock_24h", true)
    val showDate: Boolean get() = sp.getBoolean("show_date", true)
    val showInfo: Boolean get() = sp.getBoolean("show_info", true)
    val showSearch: Boolean get() = sp.getBoolean("show_search", true)
    val showDock: Boolean get() = sp.getBoolean("show_dock", true)
    val showWidgetArea: Boolean get() = sp.getBoolean("show_widget_area", true)
    val widgetHeight: Int get() = sp.getInt("widget_height", 160)

    // Gaveta
    val drawerColumns: Int get() = sp.getInt("drawer_columns", 4).coerceIn(3, 6)
    val letterHeaders: Boolean get() = sp.getBoolean("letter_headers", true)
    val autoFocus: Boolean get() = sp.getBoolean("drawer_autofocus", false)

    /** Duração escalada pela velocidade de animação (200% = metade do tempo). */
    fun dur(base: Long): Long = (base * 100f / animSpeed).toLong().coerceAtLeast(1L)

    // Favoritos (chaves de componente, em ordem)
    var favorites: List<String>
        get() = (sp.getString("favorites", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("favorites", v.joinToString("\n")).apply() }

    fun toggleFavorite(key: String): Boolean {
        val f = favorites.toMutableList()
        val added = if (f.remove(key)) false else { f.add(key); true }
        favorites = f
        return added
    }

    // Categorias personalizadas
    var categories: List<String>
        get() = try {
            val a = JSONArray(sp.getString("categories", "[]"))
            (0 until a.length()).map { a.getString(it) }
        } catch (e: JSONException) {
            emptyList()
        }
        set(v) { sp.edit().putString("categories", JSONArray(v).toString()).apply() }

    private fun catMap(): JSONObject = try {
        JSONObject(sp.getString("category_map", "{}") ?: "{}")
    } catch (e: JSONException) {
        JSONObject()
    }

    fun categoryOf(key: String): String? {
        val s = catMap().optString(key, "")
        return if (s.isEmpty()) null else s
    }

    fun setCategory(key: String, cat: String?) {
        val m = catMap()
        if (cat == null) m.remove(key) else m.put(key, cat)
        sp.edit().putString("category_map", m.toString()).apply()
    }

    fun addCategory(name: String) {
        val n = name.trim()
        if (n.isEmpty() || categories.any { it.equals(n, ignoreCase = true) }) return
        categories = categories + n
    }

    fun removeCategory(name: String) {
        categories = categories - name
        val m = catMap()
        val keys = m.keys().asSequence().toList()
        for (k in keys) if (m.optString(k) == name) m.remove(k)
        sp.edit().putString("category_map", m.toString()).apply()
    }

    // Widgets hospedados
    var widgetIds: List<Int>
        get() = (sp.getString("widget_ids", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }
        set(v) { sp.edit().putString("widget_ids", v.joinToString(",")).apply() }

    fun applyTheme(mode: String = themeMode) {
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                else -> AppCompatDelegate.MODE_NIGHT_YES
            }
        )
    }

    fun resetFavoritesAndCategories() {
        sp.edit().remove("favorites").remove("categories").remove("category_map").apply()
    }

    fun resetAll() {
        val host = AppWidgetHost(ctx, WIDGET_HOST_ID)
        widgetIds.forEach { try { host.deleteAppWidgetId(it) } catch (e: Exception) { } }
        sp.edit().clear().apply()
        applyTheme()
    }
}
