package com.nexus.launcher.util

import android.app.WallpaperManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlin.concurrent.thread

object WallpaperHelper {
    fun set(context: Context, uri: Uri) {
        val app = context.applicationContext
        val main = Handler(Looper.getMainLooper())
        thread(name = "nexus-wallpaper") {
            val ok = try {
                app.contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(app).setStream(it) }
                true
            } catch (e: Exception) {
                false
            }
            main.post {
                Toast.makeText(
                    app,
                    if (ok) "Papel de parede atualizado" else "Não foi possível definir o papel de parede",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
