package com.nexus.launcher.ui.home

import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nexus.launcher.R
import com.nexus.launcher.data.AppInfo
import com.nexus.launcher.data.AppRepository
import com.nexus.launcher.data.IconLoader
import com.nexus.launcher.data.IconPackManager
import com.nexus.launcher.data.Prefs
import com.nexus.launcher.settings.SettingsActivity
import com.nexus.launcher.util.Dialogs
import com.nexus.launcher.util.Glass
import com.nexus.launcher.util.WallpaperHelper
import com.nexus.launcher.util.dpi
import com.nexus.launcher.util.isNight
import com.nexus.launcher.util.normalized
import com.nexus.launcher.util.themeColor
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class HomeActivity : AppCompatActivity() {

    companion object {
        const val ACTION_KEY = "nexus_action"
        private const val REQ_BIND = 201
        private const val REQ_CONFIG = 202
        private const val FILTER_ALL = "\u0001all"
        private const val FILTER_FAV = "\u0001fav"
    }

    private lateinit var prefs: Prefs
    private lateinit var repo: AppRepository
    private lateinit var loader: IconLoader

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: View
    private lateinit var clock: TextClock
    private lateinit var date: TextClock
    private lateinit var infoPanel: View
    private lateinit var batteryText: TextView
    private lateinit var batteryBar: ProgressBar
    private lateinit var storageText: TextView
    private lateinit var ramText: TextView
    private lateinit var deviceText: TextView
    private lateinit var widgetPanel: FrameLayout
    private lateinit var widgetRow: LinearLayout
    private lateinit var widgetHint: TextView
    private lateinit var searchBar: TextView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: FrameLayout
    private lateinit var drawerPanel: View
    private lateinit var drawerHandle: View
    private lateinit var drawerHandleArea: View
    private lateinit var searchInput: EditText
    private lateinit var btnSettings: TextView
    private lateinit var chipRow: LinearLayout
    private lateinit var recycler: RecyclerView
    private lateinit var emptyView: TextView

    private lateinit var adapter: AppAdapter
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private lateinit var wallpaperPicker: ActivityResultLauncher<String>

    private val main = Handler(Looper.getMainLooper())
    private var apps: List<AppInfo> = emptyList()
    private var filter = FILTER_ALL
    private var drawerOpen = false
    private var pendingWidgetId = -1
    private var lastWidgetSig = ""
    private var lastSpan = -1
    private var currentBlur = 0f
    private var blurAnim: ValueAnimator? = null

    private val reloadRunnable = Runnable { reloadApps() }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i != null) updateBattery(i)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            main.removeCallbacks(reloadRunnable)
            main.postDelayed(reloadRunnable, 500)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_home)

        prefs = Prefs(this)
        repo = AppRepository(this)
        loader = IconLoader(this, prefs, IconPackManager(this))
        widgetHost = AppWidgetHost(this, Prefs.WIDGET_HOST_ID)
        awm = AppWidgetManager.getInstance(this)

        bindViews()
        setupInsets()
        setupDrawer()
        setupGestures()

        wallpaperPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) WallpaperHelper.set(this, uri)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) closeDrawer()
            }
        })

        ContextCompat.registerReceiver(
            this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )?.let { updateBattery(it) }

        val pf = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, pf, ContextCompat.RECEIVER_NOT_EXPORTED)

        reloadApps()
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        applyPrefs()
        refreshSystemInfo()
    }

    override fun onStop() {
        super.onStop()
        try { widgetHost.stopListening() } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        loader.shutdown()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val action = i.getStringExtra(ACTION_KEY)
        i.removeExtra(ACTION_KEY)
        when (action) {
            "add_widget" -> root.post { showWidgetPicker() }
            "remove_widget" -> root.post { showRemoveWidget() }
            else -> if (i.hasCategory(Intent.CATEGORY_HOME) && drawerOpen) closeDrawer()
        }
    }

    // ---------------------------------------------------------------- setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        homeLayer = findViewById(R.id.homeLayer)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        infoPanel = findViewById(R.id.infoPanel)
        batteryText = findViewById(R.id.batteryText)
        batteryBar = findViewById(R.id.batteryBar)
        storageText = findViewById(R.id.storageText)
        ramText = findViewById(R.id.ramText)
        deviceText = findViewById(R.id.deviceText)
        widgetPanel = findViewById(R.id.widgetPanel)
        widgetRow = findViewById(R.id.widgetRow)
        widgetHint = findViewById(R.id.widgetHint)
        searchBar = findViewById(R.id.searchBar)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        drawerPanel = findViewById(R.id.drawerPanel)
        drawerHandle = findViewById(R.id.drawerHandle)
        drawerHandleArea = findViewById(R.id.drawerHandleArea)
        searchInput = findViewById(R.id.searchInput)
        btnSettings = findViewById(R.id.btnSettings)
        chipRow = findViewById(R.id.chipRow)
        recycler = findViewById(R.id.recycler)
        emptyView = findViewById(R.id.emptyView)
    }

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.ime() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupDrawer() {
        adapter = AppAdapter(loader, { a, v -> launchApp(a, v) }, { a, v -> showAppMenu(a, v) })
        recycler.adapter = adapter
        recycler.itemAnimator = null

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refreshDrawer()
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH) {
                val first = adapter.rows.firstOrNull { it is Row.App } as? Row.App
                val q = searchInput.text.toString().trim()
                if (first != null) launchApp(first.info, searchInput)
                else if (q.isNotEmpty()) webSearch(q)
                true
            } else false
        }
        emptyView.setOnClickListener {
            val q = searchInput.text.toString().trim()
            if (q.isNotEmpty()) webSearch(q)
        }
        btnSettings.setOnClickListener { openSettings() }
        searchBar.setOnClickListener { openDrawer(true) }

        val handleGestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { closeDrawer(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy > 600) { closeDrawer(); return true }
                return false
            }
        })
        drawerHandleArea.setOnTouchListener { _, ev -> handleGestures.onTouchEvent(ev); true }
    }

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > dpi(80) && vy < -600 && abs(vx) < abs(vy)) {
                    openDrawer()
                    return true
                }
                return false
            }
            override fun onLongPress(e: MotionEvent) {
                homeLayer.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showHomeMenu()
            }
        })
        homeLayer.setOnTouchListener { _, ev -> detector.onTouchEvent(ev); true }
    }

    // ---------------------------------------------------------------- preferências / aparência

    private fun applyPrefs() {
        val night = isNight()
        val accent = prefs.accent

        val base = if (night) Color.BLACK else Color.WHITE
        root.setBackgroundColor(ColorUtils.setAlphaComponent(base, prefs.wallpaperDim * 255 / 100))
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }

        val clockPattern = if (prefs.clock24) "HH:mm" else "hh:mm a"
        clock.format24Hour = clockPattern
        clock.format12Hour = clockPattern
        val datePattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
        date.format24Hour = datePattern
        date.format12Hour = datePattern

        date.visibility = if (prefs.showDate) View.VISIBLE else View.GONE
        infoPanel.visibility = if (prefs.showInfo) View.VISIBLE else View.GONE
        widgetPanel.visibility = if (prefs.showWidgetArea) View.VISIBLE else View.GONE
        searchBar.visibility = if (prefs.showSearch) View.VISIBLE else View.GONE
        dock.visibility = if (prefs.showDock) View.VISIBLE else View.GONE

        infoPanel.background = Glass.panel(this, prefs, 24f)
        widgetPanel.background = Glass.panel(this, prefs, 24f)
        widgetPanel.clipToOutline = true
        searchBar.background = Glass.panel(this, prefs, 26f, 1.2f, ColorUtils.setAlphaComponent(accent, 110))
        searchBar.compoundDrawableTintList = ColorStateList.valueOf(accent)
        dock.background = Glass.panel(this, prefs, 30f, 1.1f)
        drawerPanel.background = Glass.panel(this, prefs, 30f, 1.7f)
        searchInput.background = Glass.panel(this, prefs, 24f, 1.2f)
        searchInput.compoundDrawableTintList = ColorStateList.valueOf(accent)
        drawerHandle.background = Glass.fill(this, ColorUtils.setAlphaComponent(accent, 160), 3f)

        batteryBar.progressTintList = ColorStateList.valueOf(accent)
        batteryBar.progressBackgroundTintList =
            ColorStateList.valueOf(Color.argb(60, 128, 128, 128))

        val lp = widgetPanel.layoutParams
        lp.height = dpi(prefs.widgetHeight)
        widgetPanel.layoutParams = lp

        adapter.iconPx = dpi(prefs.iconSize)
        adapter.showLabels = prefs.showLabels
        adapter.pressScale = prefs.pressScale
        adapter.accent = accent

        val span = prefs.drawerColumns
        if (span != lastSpan) {
            lastSpan = span
            val glm = GridLayoutManager(this, span)
            glm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int) = if (adapter.isHeader(position)) span else 1
            }
            recycler.layoutManager = glm
        }

        rebuildChips()
        refreshDrawer()
        refreshDock()
        restoreWidgets()
    }

    private fun refreshSystemInfo() {
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            storageText.text = "Armazenamento · ${Formatter.formatFileSize(this, st.availableBytes)} livres de ${Formatter.formatFileSize(this, st.totalBytes)}"
        } catch (e: Exception) {
            storageText.text = ""
        }
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mi)
        ramText.text = "RAM · ${Formatter.formatFileSize(this, mi.availMem)} livres de ${Formatter.formatFileSize(this, mi.totalMem)}"
        deviceText.text = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}"
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = "Bateria · $pct%" + (if (charging) " · carregando" else "")
        batteryBar.progress = pct
    }

    // ---------------------------------------------------------------- apps

    private fun reloadApps() {
        thread(name = "nexus-apps") {
            val list = repo.load()
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = list
                refreshDrawer()
                refreshDock()
            }
        }
    }

    private fun refreshDrawer() {
        if (!::adapter.isInitialized) return
        val q = searchInput.text.toString().normalized().trim()
        val list: List<AppInfo> = if (q.isNotEmpty()) {
            apps.filter { it.search.contains(q) }
        } else when (filter) {
            FILTER_ALL -> apps
            FILTER_FAV -> {
                val favs = prefs.favorites
                apps.filter { it.key in favs }
            }
            else -> apps.filter { prefs.categoryOf(it.key) == filter }
        }
        adapter.submit(list, prefs.letterHeaders && q.isEmpty())
        if (list.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            emptyView.text = when {
                q.isNotEmpty() -> "Nenhum app encontrado.\nToque para pesquisar “${searchInput.text.toString().trim()}” na web"
                filter == FILTER_FAV -> "Nenhum favorito ainda.\nSegure um app e escolha “Adicionar aos favoritos”."
                filter != FILTER_ALL -> "Esta categoria está vazia.\nSegure um app e escolha “Categoria…”."
                else -> "Carregando aplicativos…"
            }
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private fun rebuildChips() {
        chipRow.removeAllViews()
        chipRow.addView(makeChip("Todos", filter == FILTER_ALL, { setFilter(FILTER_ALL) }, null))
        chipRow.addView(makeChip("★ Favoritos", filter == FILTER_FAV, { setFilter(FILTER_FAV) }, null))
        for (c in prefs.categories) {
            chipRow.addView(makeChip(c, filter == c, { setFilter(c) }, { confirmDeleteCategory(c) }))
        }
        chipRow.addView(makeChip("＋ Categoria", false, {
            Dialogs.promptText(this, "Nova categoria", "Nome da categoria") { n ->
                prefs.addCategory(n)
                rebuildChips()
            }
        }, null))
    }

    private fun makeChip(text: String, selected: Boolean, onClick: () -> Unit, onLong: (() -> Unit)?): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 13f
        tv.setPadding(dpi(14), dpi(7), dpi(14), dpi(7))
        if (selected) {
            tv.setTextColor(Color.BLACK)
            tv.background = Glass.fill(this, prefs.accent, 18f)
        } else {
            tv.setTextColor(themeColor(android.R.attr.textColorPrimary))
            tv.background = Glass.panel(this, prefs, 18f, 1.2f)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dpi(8)
        tv.layoutParams = lp
        tv.setOnClickListener { onClick() }
        if (onLong != null) tv.setOnLongClickListener { onLong(); true }
        return tv
    }

    private fun setFilter(f: String) {
        filter = f
        rebuildChips()
        refreshDrawer()
        recycler.scrollToPosition(0)
    }

    private fun confirmDeleteCategory(name: String) {
        AlertDialog.Builder(this)
            .setMessage("Excluir a categoria “$name”? Os apps continuam instalados.")
            .setPositiveButton("Excluir") { _, _ ->
                prefs.removeCategory(name)
                if (filter == name) filter = FILTER_ALL
                rebuildChips()
                refreshDrawer()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun refreshDock() {
        dock.removeAllViews()
        val favs = prefs.favorites.mapNotNull { k -> apps.firstOrNull { it.key == k } }.take(5)
        if (favs.isEmpty()) {
            val hint = TextView(this)
            hint.text = "Segure um app na gaveta para fixá-lo aqui"
            hint.textSize = 13f
            hint.alpha = 0.7f
            hint.gravity = android.view.Gravity.CENTER
            hint.setTextColor(themeColor(android.R.attr.textColorPrimary))
            dock.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        for (a in favs) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(dpi(8), dpi(8), dpi(8), dpi(8))
            iv.contentDescription = a.label
            loader.load(a, dpi(prefs.iconSize), iv)
            iv.setOnClickListener { launchApp(a, iv) }
            iv.setOnLongClickListener {
                prefs.toggleFavorite(a.key)
                refreshDock()
                refreshDrawer()
                Toast.makeText(this, "${a.label} removido dos favoritos", Toast.LENGTH_SHORT).show()
                true
            }
            iv.setOnTouchListener { v, e ->
                if (prefs.pressScale) {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(90).start()
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                            v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                    }
                }
                false
            }
            dock.addView(iv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
    }

    private fun launchApp(app: AppInfo, v: View) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts: Bundle? = when (prefs.launchAnim) {
            "zoom" -> ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()
            "reveal" -> ActivityOptions.makeClipRevealAnimation(v, 0, 0, v.width, v.height).toBundle()
            "fade" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
            else -> null
        }
        try {
            startActivity(intent, opts)
            if (drawerOpen) root.postDelayed({ closeDrawer(false) }, 450)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(a: AppInfo, anchor: View) {
        val pm = PopupMenu(this, anchor)
        val fav = a.key in prefs.favorites
        pm.menu.add(0, 1, 0, if (fav) "Remover dos favoritos" else "Adicionar aos favoritos")
        pm.menu.add(0, 2, 1, "Categoria…")
        pm.menu.add(0, 3, 2, "Informações do app")
        pm.menu.add(0, 4, 3, "Desinstalar")
        pm.setOnMenuItemClickListener { item ->
            try {
                when (item.itemId) {
                    1 -> {
                        prefs.toggleFavorite(a.key)
                        refreshDock()
                        refreshDrawer()
                    }
                    2 -> chooseCategory(a)
                    3 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}"))
                    )
                    4 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.packageName}")))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Ação indisponível para este app", Toast.LENGTH_SHORT).show()
            }
            true
        }
        pm.show()
    }

    private fun chooseCategory(a: AppInfo) {
        val cats = prefs.categories
        val items = ArrayList<String>()
        items.add("Sem categoria")
        items.addAll(cats)
        items.add("＋ Nova categoria…")
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(items.toTypedArray()) { _, i ->
                when {
                    i == 0 -> prefs.setCategory(a.key, null)
                    i == items.size - 1 -> Dialogs.promptText(this, "Nova categoria", "Nome da categoria") { n ->
                        prefs.addCategory(n)
                        prefs.setCategory(a.key, n)
                        rebuildChips()
                        refreshDrawer()
                    }
                    else -> prefs.setCategory(a.key, cats[i - 1])
                }
                rebuildChips()
                refreshDrawer()
            }
            .show()
    }

    private fun webSearch(q: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Nenhum navegador disponível", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun showHomeMenu() {
        val items = arrayOf("Adicionar widget", "Remover widget", "Alterar papel de parede", "Configurações do Nexus")
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showWidgetPicker()
                    1 -> showRemoveWidget()
                    2 -> wallpaperPicker.launch("image/*")
                    3 -> openSettings()
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- gaveta: abrir / fechar

    private fun openDrawer(focusSearch: Boolean = false) {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        val d = prefs.dur(340)
        drawerPanel.animate().cancel()
        drawerPanel.alpha = 0f
        drawerPanel.translationY = 0f
        drawerPanel.scaleX = 1f
        drawerPanel.scaleY = 1f
        when (prefs.drawerAnim) {
            "zoom" -> { drawerPanel.scaleX = 0.86f; drawerPanel.scaleY = 0.86f }
            "fade" -> {}
            else -> drawerPanel.translationY = root.height * 0.18f
        }
        drawerPanel.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(d).setInterpolator(DecelerateInterpolator(1.8f)).start()
        homeLayer.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(d).start()
        animateBlur(prefs.blurRadius.toFloat(), d)
        if (focusSearch || prefs.autoFocus) {
            searchInput.requestFocus()
            searchInput.postDelayed({
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
            }, 200)
        }
    }

    private fun closeDrawer(animated: Boolean = true) {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.setText("")
        searchInput.clearFocus()
        recycler.scrollToPosition(0)
        if (!animated) {
            drawerPanel.animate().cancel()
            homeLayer.animate().cancel()
            drawer.visibility = View.GONE
            homeLayer.alpha = 1f
            homeLayer.scaleX = 1f
            homeLayer.scaleY = 1f
            blurAnim?.cancel()
            if (Build.VERSION.SDK_INT >= 31) applyBlur(0f)
            return
        }
        val d = prefs.dur(260)
        val anim = drawerPanel.animate().alpha(0f).setDuration(d)
        when (prefs.drawerAnim) {
            "zoom" -> anim.scaleX(0.9f).scaleY(0.9f)
            "fade" -> {}
            else -> anim.translationY(root.height * 0.12f)
        }
        anim.withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }.start()
        homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(d).start()
        animateBlur(0f, d)
    }

    private fun animateBlur(to: Float, d: Long) {
        blurAnim?.cancel()
        if (Build.VERSION.SDK_INT < 31) return
        if (!prefs.blurTransitions || (to == 0f && currentBlur == 0f)) {
            applyBlur(0f)
            return
        }
        blurAnim = ValueAnimator.ofFloat(currentBlur, to).setDuration(d).apply {
            addUpdateListener { applyBlur(it.animatedValue as Float) }
            start()
        }
    }

    /** Blur do conteúdo da home (RenderEffect) e do fundo/papel de parede (blur de janela), Android 12+. */
    @RequiresApi(31)
    private fun applyBlur(r: Float) {
        currentBlur = r
        homeLayer.setRenderEffect(
            if (r > 0.5f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null
        )
        window.setBackgroundBlurRadius(r.toInt())
    }

    // ---------------------------------------------------------------- widgets reais (AppWidgetHost)

    private fun showWidgetPicker() {
        val providers = awm.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "Nenhum widget disponível neste aparelho", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = providers.map { p ->
            val app = try {
                packageManager.getApplicationLabel(p.providerInfo.applicationInfo).toString()
            } catch (e: Exception) {
                p.provider.packageName
            }
            "$app · ${p.loadLabel(packageManager)}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolher widget")
            .setItems(labels) { _, i -> bindWidget(providers[i]) }
            .show()
    }

    private fun bindWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrAdd(id, info)
        } else {
            pendingWidgetId = id
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                widgetHost.deleteAppWidgetId(id)
                pendingWidgetId = -1
                Toast.makeText(this, "Este aparelho não permitiu vincular o widget", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun configureOrAdd(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            pendingWidgetId = id
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                finishAddWidget(id)
                pendingWidgetId = -1
            }
        } else {
            finishAddWidget(id)
        }
    }

    private fun finishAddWidget(id: Int) {
        prefs.widgetIds = prefs.widgetIds + id
        restoreWidgets(true)
    }

    @Deprecated("Necessário para AppWidgetHost")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_BIND && requestCode != REQ_CONFIG) return
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
        if (resultCode != RESULT_OK) {
            if (id != -1) widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
            return
        }
        if (requestCode == REQ_BIND) {
            val info = awm.getAppWidgetInfo(id)
            if (info != null) configureOrAdd(id, info)
        } else {
            finishAddWidget(id)
            pendingWidgetId = -1
        }
    }

    private fun restoreWidgets(force: Boolean = false) {
        val saved = prefs.widgetIds
        val ids = saved.filter { awm.getAppWidgetInfo(it) != null }
        if (ids != saved) prefs.widgetIds = ids
        val sig = ids.joinToString(",") + "|" + prefs.widgetHeight
        if (!force && sig == lastWidgetSig) return
        lastWidgetSig = sig

        widgetRow.removeAllViews()
        widgetHint.visibility = if (ids.isEmpty()) View.VISIBLE else View.GONE
        val density = resources.displayMetrics.density
        val hPx = dpi(prefs.widgetHeight)
        val wPx = (resources.displayMetrics.widthPixels * 0.8f).toInt()
        for (id in ids) {
            val info = awm.getAppWidgetInfo(id) ?: continue
            val hv: AppWidgetHostView = widgetHost.createView(this, id, info)
            hv.setOnLongClickListener { confirmRemoveWidget(id); true }
            val lp = LinearLayout.LayoutParams(
                if (ids.size == 1) ViewGroup.LayoutParams.MATCH_PARENT else wPx, hPx
            )
            widgetRow.addView(hv, lp)
            hv.post {
                val w = (wPx / density).toInt()
                val h = (hPx / density).toInt()
                hv.updateAppWidgetSize(null, w, h, w, h)
            }
        }
    }

    private fun confirmRemoveWidget(id: Int) {
        AlertDialog.Builder(this)
            .setMessage("Remover este widget da tela inicial?")
            .setPositiveButton("Remover") { _, _ -> removeWidget(id) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showRemoveWidget() {
        val ids = prefs.widgetIds
        if (ids.isEmpty()) {
            Toast.makeText(this, "Nenhum widget adicionado", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = ids.map { awm.getAppWidgetInfo(it)?.loadLabel(packageManager) ?: "Widget $it" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Remover qual widget?")
            .setItems(labels) { _, i -> removeWidget(ids[i]) }
            .show()
    }

    private fun removeWidget(id: Int) {
        try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) { }
        prefs.widgetIds = prefs.widgetIds - id
        restoreWidgets(true)
    }
}
