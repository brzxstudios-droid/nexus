# Nexus Launcher

Launcher Android (Kotlin, Views + AndroidX) com visual glassmorphism escuro. Android 10+ (minSdk 29, targetSdk 34).

## Como compilar e gerar o APK

1. Instale o **Android Studio** (Koala ou mais recente). Ele traz o JDK 17 e o SDK.
2. `File > Open` e escolha a pasta `NexusLauncher`. Aceite a instalação do **Android SDK 34** se solicitado.
3. Aguarde o *Gradle Sync* (o Android Studio baixa o Gradle 8.7 sozinho, a partir de `gradle-wrapper.properties`).
4. APK de teste: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   Saída: `app/build/outputs/apk/debug/app-debug.apk`.
5. APK otimizado: `Build > Select Build Variant > release` e repita o passo 4.
   Saída: `app/build/outputs/apk/release/app-release.apk` (assinado com a chave de debug, instalável direto).
   Para publicar de verdade, use `Build > Generate Signed Bundle / APK` com sua própria keystore.
6. Pela linha de comando (depois de abrir uma vez no Android Studio): `./gradlew assembleDebug`.
   Se `gradlew` não existir, rode `gradle wrapper --gradle-version 8.7` ou use o Android Studio.

## Instalação e uso como Home

- Transfira o APK ao aparelho e instale (permita "fontes desconhecidas"), ou use `adb install app-debug.apk`.
- Aperte o botão Home: o Android pergunta qual launcher usar. Escolha **Nexus Launcher > Sempre**.
  Também dá para ir em *Ajustes do Nexus > Personalização avançada > Definir como launcher padrão*.
- O app "Configurações do Nexus" aparece também em outros launchers, caso precise voltar.

## Uso

- Deslize para cima na tela inicial (ou toque na barra de pesquisa) para abrir a gaveta.
- Segure em um espaço vazio da home: adicionar/remover widget, trocar papel de parede, configurações.
- Na gaveta, segure um app: favoritos (dock), categoria, informações, desinstalar.
- Segure um ícone do dock para tirá-lo dos favoritos; segure um widget para removê-lo.
- Chips da gaveta: Todos, Favoritos, suas categorias; "＋ Categoria" cria uma nova; segure uma categoria para excluir.

## Estrutura

```
app/src/main/java/com/nexus/launcher/
  NexusApp.kt                 aplica tema claro/escuro salvo
  data/   Prefs, AppInfo, AppRepository (PackageManager), IconPackManager (appfilter.xml), IconLoader (cache/forma)
  ui/home HomeActivity (home, gaveta, widgets via AppWidgetHost, animações), AppAdapter
  settings SettingsActivity + Sections.kt (7 seções)
  util    Glass (painéis de vidro), Ext, Dialogs, WallpaperHelper
```

## Observações de compatibilidade

- **Blur real** (blur do conteúdo e do papel de parede nas transições) exige Android 12+ e um aparelho com blur entre janelas habilitado.
  No Android 10/11 o visual usa painéis translúcidos com brilho, sem blur; o restante funciona igual.
- Widgets: o Nexus usa o `AppWidgetHost` oficial; alguns widgets pedem uma permissão de vinculação, que o sistema exibe ao adicionar.
- Pacotes de ícones: compatíveis com o padrão Nova/ADW/GO (`appfilter.xml`).
- O papel de parede é definido via `WallpaperManager` (permissão `SET_WALLPAPER`).
