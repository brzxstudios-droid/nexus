# Nexus Launcher 1.0.0 (build 1001)

Launcher Android (Kotlin, Views + AndroidX), Android 10+ (minSdk 29, targetSdk 34).

## Telas
- **Tela inicial:** relógio (5 estilos), data, clima real (Open-Meteo), barra de pesquisa (voz e imagem), grade de favoritos em páginas (8 por página, com pontinhos), dock (Telefone, Mensagens, Câmera + botão da gaveta) e widgets do Android (opcional).
- **Gaveta (tela cheia):** pesquisa, abas com sublinhado (Tudo, Jogos, Redes, Ferramentas, suas categorias), grade com nomes dos apps e índice A–Z.
- **Configurações:** Aparência, Ícones, Widgets, Animações, Tela Inicial, Gaveta, Avançado e Sobre; com busca.

## Compilar
Android Studio: `Build > Build APK(s)`. Ou use o workflow `.github/workflows/build.yml` no GitHub.

## Observações
- Blur real (conteúdo e papel de parede) exige Android 12+.
- Clima: defina a cidade (toque no cartão de clima). Requer internet.
- Pacotes de ícones: padrão Nova/ADW/GO (`appfilter.xml`).
