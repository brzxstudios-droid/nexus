# Fragments de configurações são referenciados por nome nos XMLs; o AAPT já gera as regras keep.
