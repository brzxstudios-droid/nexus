package com.nexus.launcher.ui.home

import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nexus.launcher.data.AppInfo
import com.nexus.launcher.data.IconLoader
import com.nexus.launcher.data.Prefs
import com.nexus.launcher.util.dpi

/** Páginas da grade de favoritos (2 linhas x 4 colunas por página). */
class FavPagerAdapter(
    private val loader: IconLoader,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLong: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<FavPagerAdapter.VH>() {

    var pages: List<List<AppInfo>> = emptyList()
        private set
    var iconPx = 150
    var showLabels = true
    var pressScale = true
    var textColor = Color.WHITE

    fun submit(favs: List<AppInfo>) {
        pages = favs.chunked(Prefs.PER_PAGE)
        notifyDataSetChanged()
    }

    class VH(val box: LinearLayout) : RecyclerView.ViewHolder(box)

    override fun getItemCount() = pages.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ll = LinearLayout(parent.context)
        ll.orientation = LinearLayout.VERTICAL
        ll.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        return VH(ll)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val box = h.box
        val ctx = box.context
        box.removeAllViews()
        val items = pages[position]
        for (r in 0 until 2) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 4) {
                val idx = r * 4 + c
                val cell = LinearLayout(ctx)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                if (idx < items.size) {
                    val a = items[idx]
                    val iv = ImageView(ctx)
                    loader.load(a, iconPx, iv)
                    cell.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx))
                    if (showLabels) {
                        val tv = TextView(ctx)
                        tv.text = a.label
                        tv.textSize = 11f
                        tv.maxLines = 1
                        tv.ellipsize = TextUtils.TruncateAt.END
                        tv.gravity = Gravity.CENTER
                        tv.setTextColor(textColor)
                        tv.setShadowLayer(4f, 0f, 1f, Color.argb(150, 0, 0, 0))
                        val lp = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        lp.topMargin = ctx.dpi(5)
                        cell.addView(tv, lp)
                    }
                    cell.setOnClickListener { onClick(a, iv) }
                    cell.setOnLongClickListener { onLong(a, cell); true }
                    cell.setOnTouchListener { v, e ->
                        if (pressScale) {
                            when (e.actionMasked) {
                                MotionEvent.ACTION_DOWN ->
                                    v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                                    v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                            }
                        }
                        false
                    }
                }
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
    }
}
