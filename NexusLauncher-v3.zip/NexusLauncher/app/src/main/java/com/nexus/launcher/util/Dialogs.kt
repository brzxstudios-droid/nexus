package com.nexus.launcher.util

import android.content.Context
import android.widget.EditText
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog

object Dialogs {
    fun promptText(
        ctx: Context, title: String, hint: String,
        neutralLabel: String? = null, onNeutral: (() -> Unit)? = null,
        onOk: (String) -> Unit
    ) {
        val et = EditText(ctx).apply {
            this.hint = hint
            setSingleLine()
        }
        val box = FrameLayout(ctx).apply {
            setPadding(ctx.dpi(20), ctx.dpi(8), ctx.dpi(20), 0)
            addView(et)
        }
        val b = AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancelar", null)
        if (neutralLabel != null && onNeutral != null) b.setNeutralButton(neutralLabel) { _, _ -> onNeutral() }
        b.show()
    }
}
