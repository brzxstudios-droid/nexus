package com.nexus.launcher.ui.home

import android.graphics.Color
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nexus.launcher.R
import com.nexus.launcher.data.AppInfo
import com.nexus.launcher.data.IconLoader
import com.nexus.launcher.util.normalized

sealed class Row {
    data class Header(val letter: String) : Row()
    data class App(val info: AppInfo) : Row()
}

class AppAdapter(
    private val loader: IconLoader,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLong: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var rows: List<Row> = emptyList()
        private set
    var iconPx = 160
    var showLabels = true
    var pressScale = true
    var accent = Color.CYAN
    var textColor = Color.WHITE

    fun isHeader(position: Int) = rows.getOrNull(position) is Row.Header

    fun submit(apps: List<AppInfo>, headers: Boolean) {
        val out = ArrayList<Row>(apps.size + 28)
        var last = ""
        for (a in apps) {
            if (headers) {
                val first = a.label.normalized().firstOrNull()
                val l = if (first != null && first.isLetter()) first.uppercaseChar().toString() else "#"
                if (l != last) {
                    out.add(Row.Header(l))
                    last = l
                }
            }
            out.add(Row.App(a))
        }
        rows = out
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int) = if (rows[position] is Row.Header) 0 else 1
    override fun getItemCount() = rows.size

    class AppVH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
        val text = v as TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == 0) HeaderVH(inf.inflate(R.layout.item_header, parent, false))
        else AppVH(inf.inflate(R.layout.item_app, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> {
                val h = holder as HeaderVH
                h.text.text = row.letter
                h.text.setTextColor(accent)
            }
            is Row.App -> {
                val h = holder as AppVH
                val a = row.info
                val lp = h.icon.layoutParams
                lp.width = iconPx
                lp.height = iconPx
                h.icon.layoutParams = lp
                loader.load(a, iconPx, h.icon)
                h.label.visibility = if (showLabels) View.VISIBLE else View.GONE
                h.label.text = a.label
                h.label.setTextColor(textColor)
                h.label.setShadowLayer(4f, 0f, 1f, Color.argb(140, 0, 0, 0))
                h.itemView.setOnClickListener { onClick(a, h.icon) }
                h.itemView.setOnLongClickListener { onLong(a, h.itemView); true }
                h.itemView.setOnTouchListener { v, e ->
                    if (pressScale) {
                        when (e.actionMasked) {
                            MotionEvent.ACTION_DOWN ->
                                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                        }
                    }
                    false
                }
            }
        }
    }
}
