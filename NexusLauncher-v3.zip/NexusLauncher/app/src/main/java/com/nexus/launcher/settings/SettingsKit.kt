package com.nexus.launcher.settings

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.graphics.ColorUtils
import com.nexus.launcher.R
import com.nexus.launcher.data.Prefs
import com.nexus.launcher.util.Glass
import com.nexus.launcher.util.dpi
import com.nexus.launcher.util.themeColor

/** Componentes de interface (vidro) das telas de configurações. Tudo grava direto nas Prefs. */
class SettingsKit(val ctx: Context, val prefs: Prefs) {
    val txt: Int = ctx.themeColor(android.R.attr.textColorPrimary)
    val sub: Int = ColorUtils.setAlphaComponent(txt, 160)
    val accent: Int get() = prefs.accent

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).apply { setMargins(ctx.dpi(start), ctx.dpi(top), ctx.dpi(end), ctx.dpi(bottom)) }

    fun text(s: String, size: Float, color: Int = txt, family: String = "sans-serif"): TextView {
        val tv = TextView(ctx)
        tv.text = s
        tv.textSize = size
        tv.setTextColor(color)
        tv.typeface = Typeface.create(family, Typeface.NORMAL)
        return tv
    }

    fun tint(iv: ImageView, color: Int = txt) {
        iv.imageTintList = ColorStateList.valueOf(color)
    }

    private fun touchFeedback(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.alpha = 0.6f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.alpha = 1f
            }
            false
        }
    }

    // ------------------------------------------------------------ estrutura

    fun header(title: String, onBack: (() -> Unit)?): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        if (onBack != null) {
            val b = ImageView(ctx)
            b.setImageResource(R.drawable.ic_back)
            tint(b)
            b.setPadding(ctx.dpi(8), ctx.dpi(8), ctx.dpi(8), ctx.dpi(8))
            b.contentDescription = "Voltar"
            b.setOnClickListener { onBack() }
            row.addView(b, lp(ctx.dpi(44), ctx.dpi(44), end = 6))
        }
        row.addView(text(title, 26f, txt, "sans-serif-medium"))
        row.layoutParams = lp(top = 10, bottom = 10)
        return row
    }

    fun label(s: String): TextView {
        val tv = text(s, 13f, sub, "sans-serif-medium")
        tv.layoutParams = lp(top = 22, bottom = 8, start = 4)
        return tv
    }

    fun card(vararg rows: View): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = Glass.panel(ctx, prefs, 22f, 1.4f)
        c.layoutParams = lp(top = 4)
        rows.forEachIndexed { i, r ->
            if (i > 0) {
                val d = View(ctx)
                d.setBackgroundColor(ColorUtils.setAlphaComponent(txt, 28))
                c.addView(d, lp(h = 1, start = 16))
            }
            c.addView(r)
        }
        return c
    }

    fun badge(res: Int): View {
        val box = FrameLayout(ctx)
        box.background = Glass.fill(ctx, ColorUtils.setAlphaComponent(txt, 26), 20f)
        val iv = ImageView(ctx)
        iv.setImageResource(res)
        tint(iv)
        box.addView(iv, FrameLayout.LayoutParams(ctx.dpi(22), ctx.dpi(22), Gravity.CENTER))
        return box
    }

    fun chevron(): ImageView {
        val iv = ImageView(ctx)
        iv.setImageResource(R.drawable.ic_chevron)
        tint(iv, sub)
        iv.layoutParams = LinearLayout.LayoutParams(ctx.dpi(20), ctx.dpi(20))
        return iv
    }

    fun valueText(s: String): TextView = text(s, 14f, sub)

    fun rowBase(icon: Int?, title: String, subtitle: String?, trailing: View?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(ctx.dpi(14), ctx.dpi(12), ctx.dpi(14), ctx.dpi(12))
        r.minimumHeight = ctx.dpi(58)
        if (icon != null) r.addView(badge(icon), lp(ctx.dpi(40), ctx.dpi(40), end = 14))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(title, 15f, txt, "sans-serif-medium"))
        if (!subtitle.isNullOrEmpty()) col.addView(text(subtitle, 12f, sub))
        r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (trailing != null) r.addView(trailing)
        if (onClick != null) {
            r.isClickable = true
            r.setOnClickListener { onClick() }
            touchFeedback(r)
        }
        return r
    }

    // ------------------------------------------------------------ linhas

    fun navRow(icon: Int?, title: String, subtitle: String?, onClick: () -> Unit): View =
        rowBase(icon, title, subtitle, chevron(), onClick)

    fun actionRow(icon: Int?, title: String, subtitle: String?, onClick: () -> Unit): View =
        rowBase(icon, title, subtitle, null, onClick)

    fun infoRow(label: String, value: String): View =
        rowBase(null, label, null, valueText(value), null)

    fun switchRow(icon: Int?, title: String, subtitle: String?, key: String, def: Boolean, onChange: ((Boolean) -> Unit)? = null): View {
        val sw = SwitchCompat(ctx)
        sw.isChecked = prefs.sp.getBoolean(key, def)
        val onColor = Color.parseColor("#2F80FF")
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.argb(255, 140, 140, 148)))
        sw.trackTintList = ColorStateList(
            states, intArrayOf(onColor, ColorUtils.setAlphaComponent(txt, 45))
        )
        sw.setOnCheckedChangeListener { _, c ->
            prefs.sp.edit().putBoolean(key, c).apply()
            onChange?.invoke(c)
        }
        return rowBase(icon, title, subtitle, sw) { sw.toggle() }
    }

    fun sliderRow(title: String, key: String, min: Int, max: Int, def: Int, suffix: String, onChange: ((Int) -> Unit)? = null): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(ctx.dpi(16), ctx.dpi(12), ctx.dpi(16), ctx.dpi(6))
        val cur = prefs.sp.getInt(key, def).coerceIn(min, max)
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        val valueTv = valueText("$cur$suffix")
        top.addView(text(title, 15f, txt, "sans-serif-medium"), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(valueTv)
        box.addView(top)
        val sb = SeekBar(ctx)
        sb.max = max - min
        sb.progress = cur - min
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.progressBackgroundTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(txt, 60))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                valueTv.text = "$v$suffix"
                if (fromUser) {
                    prefs.sp.edit().putInt(key, v).apply()
                    onChange?.invoke(v)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, lp(top = 4))
        return box
    }

    fun choiceRow(
        icon: Int?, title: String, key: String, entries: List<String>, values: List<String>,
        def: String, onChange: ((String) -> Unit)? = null
    ): View {
        fun cur(): String = prefs.sp.getString(key, def) ?: def
        val tv = valueText(entries.getOrElse(values.indexOf(cur())) { entries[0] })
        return rowBase(icon, title, null, tv) {
            AlertDialog.Builder(ctx)
                .setTitle(title)
                .setSingleChoiceItems(entries.toTypedArray(), values.indexOf(cur()).coerceAtLeast(0)) { d, which ->
                    prefs.sp.edit().putString(key, values[which]).apply()
                    tv.text = entries[which]
                    d.dismiss()
                    onChange?.invoke(values[which])
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    fun button(label: String, onClick: () -> Unit): TextView {
        val b = text(label, 15f, txt, "sans-serif-medium")
        b.gravity = Gravity.CENTER
        b.setPadding(ctx.dpi(16), ctx.dpi(14), ctx.dpi(16), ctx.dpi(14))
        b.background = Glass.panel(ctx, prefs, 18f, 1.6f, ColorUtils.setAlphaComponent(txt, 80))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        touchFeedback(b)
        return b
    }

    /** Linha com vários botões lado a lado. */
    fun buttonRow(vararg buttons: TextView): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = lp(top = 14)
        buttons.forEachIndexed { i, b ->
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i > 0) p.marginStart = ctx.dpi(10)
            row.addView(b, p)
        }
        return row
    }

    fun chipGroup(options: List<Pair<String, String>>, key: String, def: String, onChange: ((String) -> Unit)? = null): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = lp(top = 4)
        val views = ArrayList<TextView>()
        fun style() {
            val cur = prefs.sp.getString(key, def) ?: def
            options.forEachIndexed { i, o ->
                val sel = o.second == cur
                views[i].background =
                    if (sel) Glass.panel(ctx, prefs, 16f, 1.8f, accent) else Glass.panel(ctx, prefs, 16f, 1.3f)
                views[i].typeface = Typeface.create(if (sel) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
            }
        }
        options.forEachIndexed { i, o ->
            val tv = text(o.first, 14f)
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, ctx.dpi(13), 0, ctx.dpi(13))
            tv.setOnClickListener {
                prefs.sp.edit().putString(key, o.second).apply()
                style()
                onChange?.invoke(o.second)
            }
            views.add(tv)
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i > 0) p.marginStart = ctx.dpi(8)
            row.addView(tv, p)
        }
        style()
        return row
    }

    fun colorDots(onChange: () -> Unit): View {
        val colors = listOf("#FFFFFF", "#6B6B73", "#2ECC71", "#2979FF", "#7C4DFF", "#CE93D8")
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = lp(top = 4)
        val cells = ArrayList<FrameLayout>()
        fun style() {
            val raw = prefs.sp.getString("accent", "#FFFFFF") ?: "#FFFFFF"
            val custom = (prefs.sp.getString("accent_custom", "") ?: "").isNotBlank()
            colors.forEachIndexed { i, c ->
                val sel = !custom && c.equals(raw, ignoreCase = true)
                cells[i].background = if (sel) GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.TRANSPARENT)
                    setStroke(ctx.dpi(2), txt)
                } else null
            }
        }
        colors.forEachIndexed { i, c ->
            val cell = FrameLayout(ctx)
            cell.setPadding(ctx.dpi(5), ctx.dpi(5), ctx.dpi(5), ctx.dpi(5))
            val dot = View(ctx)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(c))
                setStroke(ctx.dpi(1), Color.argb(90, 128, 128, 128))
            }
            cell.addView(dot, FrameLayout.LayoutParams(ctx.dpi(32), ctx.dpi(32)))
            cell.setOnClickListener {
                prefs.sp.edit().putString("accent", c).remove("accent_custom").apply()
                style()
                onChange()
            }
            cells.add(cell)
            row.addView(cell, lp(ctx.dpi(44), ctx.dpi(44), end = 8))
        }
        style()
        return row
    }
}
