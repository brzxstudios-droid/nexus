package com.nexus.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import java.text.Collator

/** Lista os apps lançáveis usando a API oficial do PackageManager. */
class AppRepository(private val ctx: Context) {

    companion object {
        const val CAT_GAMES = "Jogos"
        const val CAT_SOCIAL = "Redes"
        const val CAT_TOOLS = "Ferramentas"
        val AUTO_CATEGORIES = listOf(CAT_GAMES, CAT_SOCIAL, CAT_TOOLS)

        private val SOCIAL = listOf(
            "whatsapp", "telegram", "instagram", "facebook", "twitter", "snapchat", "discord",
            "tiktok", "messenger", "linkedin", "reddit", "pinterest", "threads", "signal"
        )
        private val TOOLS = listOf(
            "calculator", "deskclock", "clock", "settings", "documentsui", "filemanager",
            "files", "notes", "calendar", "contacts", "dialer", "gallery"
        )
    }

    fun load(): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val collator = Collator.getInstance().apply { strength = Collator.PRIMARY }
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                val ai = it.activityInfo
                AppInfo(
                    it.loadLabel(pm).toString(),
                    ComponentName(ai.packageName, ai.name),
                    autoCategoryOf(ai.applicationInfo, ai.packageName)
                )
            }
            .distinctBy { it.key }
            .sortedWith(Comparator<AppInfo> { a, b -> collator.compare(a.label, b.label) })
    }

    @Suppress("DEPRECATION")
    private fun autoCategoryOf(info: ApplicationInfo?, pkg: String): String? {
        if (info != null) {
            when (info.category) {
                ApplicationInfo.CATEGORY_GAME -> return CAT_GAMES
                ApplicationInfo.CATEGORY_SOCIAL -> return CAT_SOCIAL
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> return CAT_TOOLS
            }
            if ((info.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return CAT_GAMES
        }
        val p = pkg.lowercase()
        if (SOCIAL.any { p.contains(it) }) return CAT_SOCIAL
        if (TOOLS.any { p.contains(it) }) return CAT_TOOLS
        return null
    }
}
