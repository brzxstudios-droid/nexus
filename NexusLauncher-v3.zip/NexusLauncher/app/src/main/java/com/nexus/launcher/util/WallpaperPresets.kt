package com.nexus.launcher.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader

/** Papéis de parede escuros gerados em código (sem arquivos de imagem). */
object WallpaperPresets {
    val names = listOf("Obsidiana", "Neon", "Montanha")

    fun render(index: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = w.toFloat()
        val hf = h.toFloat()
        c.drawColor(0xFF050505.toInt())
        when (index) {
            0 -> {
                p.shader = RadialGradient(
                    wf * 0.65f, hf * 0.3f, hf * 0.6f,
                    intArrayOf(0xFF2C2C33.toInt(), 0xFF0E0E10.toInt(), 0xFF050505.toInt()),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, wf, hf, p)
                p.shader = null
                // curvas metálicas
                p.style = Paint.Style.STROKE
                for (i in 0 until 9) {
                    p.strokeWidth = hf * (0.0045f - i * 0.0003f)
                    p.color = Color.argb(70 - i * 6, 255, 255, 255)
                    val path = Path()
                    path.moveTo(-wf * 0.1f, hf * (0.1f + i * 0.045f))
                    path.cubicTo(
                        wf * 0.35f, hf * (0.02f + i * 0.05f),
                        wf * 0.2f, hf * (0.75f - i * 0.02f),
                        wf * 1.1f, hf * (0.5f + i * 0.04f)
                    )
                    c.drawPath(path, p)
                }
                // esfera de vidro
                val cx = wf * 0.42f
                val cy = hf * 0.4f
                val r = wf * 0.36f
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(
                    cx - r * 0.3f, cy - r * 0.4f, r * 1.25f,
                    intArrayOf(0x38FFFFFF, 0x12FFFFFF, 0x00FFFFFF),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
                c.drawCircle(cx, cy, r, p)
                p.shader = null
                p.style = Paint.Style.STROKE
                p.strokeWidth = wf * 0.006f
                p.color = Color.argb(120, 255, 255, 255)
                c.drawCircle(cx, cy, r, p)
                p.strokeWidth = wf * 0.012f
                p.color = Color.argb(90, 255, 255, 255)
                c.drawArc(
                    android.graphics.RectF(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.9f, cy + r * 0.9f),
                    205f, 55f, false, p
                )
            }
            1 -> {
                p.shader = LinearGradient(
                    0f, 0f, 0f, hf,
                    intArrayOf(0xFF1A0B33.toInt(), 0xFF0A0614.toInt(), 0xFF050505.toInt()),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, wf, hf, p)
                p.shader = null
                p.style = Paint.Style.STROKE
                p.strokeWidth = hf * 0.003f
                for (i in 0 until 9) {
                    val path = Path()
                    val y = hf * (0.52f + i * 0.045f)
                    path.moveTo(0f, y)
                    path.lineTo(wf * 0.22f, y - hf * 0.09f)
                    path.lineTo(wf * 0.38f, y - hf * 0.02f)
                    path.lineTo(wf * 0.6f, y - hf * 0.16f)
                    path.lineTo(wf * 0.82f, y - hf * 0.04f)
                    path.lineTo(wf, y - hf * 0.1f)
                    p.color = if (i % 2 == 0) Color.argb(150 - i * 12, 214, 64, 255)
                    else Color.argb(120 - i * 10, 64, 180, 255)
                    c.drawPath(path, p)
                }
            }
            else -> {
                p.shader = LinearGradient(
                    0f, 0f, 0f, hf,
                    intArrayOf(0xFF0B1B33.toInt(), 0xFF07101F.toInt(), 0xFF050505.toInt()),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, wf, hf, p)
                val m = Path()
                m.moveTo(0f, hf * 0.78f)
                m.lineTo(wf * 0.25f, hf * 0.6f)
                m.lineTo(wf * 0.4f, hf * 0.72f)
                m.lineTo(wf * 0.62f, hf * 0.5f)
                m.lineTo(wf * 0.85f, hf * 0.74f)
                m.lineTo(wf, hf * 0.66f)
                m.lineTo(wf, hf)
                m.lineTo(0f, hf)
                m.close()
                p.shader = LinearGradient(
                    0f, hf * 0.5f, 0f, hf,
                    intArrayOf(0xFF4A78B8.toInt(), 0xFF0B1B33.toInt(), 0xFF050505.toInt()),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
                c.drawPath(m, p)
            }
        }
        return bmp
    }
}
