package com.nexus.launcher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors

/** Carrega ícones em segundo plano, aplica pacote de ícones e formato, e mantém cache em memória. */
class IconLoader(private val ctx: Context, private val prefs: Prefs, private val packs: IconPackManager) {
    private val cache = LruCache<String, Bitmap>(192)
    private val exec = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun load(app: AppInfo, size: Int, view: ImageView) {
        val key = "${prefs.iconPack}|${prefs.iconShape}|$size|${app.key}"
        view.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageDrawable(null)
        exec.execute {
            try {
                val bmp = render(app, size)
                cache.put(key, bmp)
                main.post { if (view.tag == key) view.setImageBitmap(bmp) }
            } catch (e: Exception) {
                // ignora ícone com falha
            }
        }
    }

    fun shutdown() = exec.shutdownNow()

    private fun render(app: AppInfo, size: Int): Bitmap {
        val pm = ctx.packageManager
        val d: Drawable = packs.iconFor(prefs.iconPack, app.component)
            ?: try {
                pm.getActivityIcon(app.component)
            } catch (e: Exception) {
                pm.defaultActivityIcon
            }
        val shape = prefs.iconShape
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable && shape != "original") {
            // Desenha as camadas sem a máscara do sistema e aplica a forma escolhida.
            val layers = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val lc = Canvas(layers)
            val inset = (size * 0.25f).toInt()
            d.background?.let { it.setBounds(-inset, -inset, size + inset, size + inset); it.draw(lc) }
            d.foreground?.let { it.setBounds(-inset, -inset, size + inset, size + inset); it.draw(lc) }
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.shader = BitmapShader(layers, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val s = size.toFloat()
            if (shape == "circle") c.drawCircle(s / 2f, s / 2f, s / 2f, paint)
            else c.drawRoundRect(0f, 0f, s, s, s * 0.28f, s * 0.28f, paint)
        } else {
            d.setBounds(0, 0, size, size)
            d.draw(c)
        }
        return bmp
    }
}
