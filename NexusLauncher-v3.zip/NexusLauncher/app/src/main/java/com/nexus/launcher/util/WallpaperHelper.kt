package com.nexus.launcher.util

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlin.concurrent.thread

object WallpaperHelper {
    private fun report(app: Context, ok: Boolean) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(
                app,
                if (ok) "Papel de parede atualizado" else "Não foi possível definir o papel de parede",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun set(context: Context, uri: Uri) {
        val app = context.applicationContext
        thread(name = "nexus-wallpaper") {
            val ok = try {
                app.contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(app).setStream(it) }
                true
            } catch (e: Exception) {
                false
            }
            report(app, ok)
        }
    }

    fun setBitmap(context: Context, bmp: Bitmap) {
        val app = context.applicationContext
        thread(name = "nexus-wallpaper") {
            val ok = try {
                WallpaperManager.getInstance(app).setBitmap(bmp)
                true
            } catch (e: Exception) {
                false
            }
            report(app, ok)
        }
    }
}
