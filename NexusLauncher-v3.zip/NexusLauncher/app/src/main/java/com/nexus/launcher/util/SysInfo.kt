package com.nexus.launcher.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter

object SysInfo {
    fun storage(ctx: Context): String = try {
        val st = StatFs(Environment.getDataDirectory().path)
        "Armazenamento · ${Formatter.formatFileSize(ctx, st.availableBytes)} livres de ${Formatter.formatFileSize(ctx, st.totalBytes)}"
    } catch (e: Exception) {
        ""
    }

    fun ram(ctx: Context): String {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mi)
        return "RAM · ${Formatter.formatFileSize(ctx, mi.availMem)} livres de ${Formatter.formatFileSize(ctx, mi.totalMem)}"
    }

    fun device(): String =
        "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}"

    /** (porcentagem, carregando) */
    fun battery(ctx: Context): Pair<Int, Boolean> {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return 0 to false
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return pct to charging
    }
}
