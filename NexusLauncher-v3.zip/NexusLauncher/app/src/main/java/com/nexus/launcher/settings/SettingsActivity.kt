package com.nexus.launcher.settings

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.nexus.launcher.R
import com.nexus.launcher.data.AppRepository
import com.nexus.launcher.data.IconPackManager
import com.nexus.launcher.data.Prefs
import com.nexus.launcher.data.WeatherRepo
import com.nexus.launcher.ui.home.HomeActivity
import com.nexus.launcher.ui.widget.AnalogClockView
import com.nexus.launcher.util.Dialogs
import com.nexus.launcher.util.Glass
import com.nexus.launcher.util.SysInfo
import com.nexus.launcher.util.WallpaperHelper
import com.nexus.launcher.util.WallpaperPresets
import com.nexus.launcher.util.dp
import com.nexus.launcher.util.dpi
import com.nexus.launcher.util.isNight
import com.nexus.launcher.util.normalized
import kotlin.concurrent.thread
import kotlin.math.abs

class SettingsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PAGE = "page"
        fun open(ctx: Context, page: String) {
            ctx.startActivity(Intent(ctx, SettingsActivity::class.java).putExtra(EXTRA_PAGE, page))
        }
    }

    private lateinit var prefs: Prefs
    private lateinit var kit: SettingsKit
    private lateinit var column: LinearLayout
    private lateinit var page: String
    private var widgetTab = 0
    private var pendingClockStyle: String? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) WallpaperHelper.set(this, uri)
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    // (texto, página, seção) usados na busca de configurações
    private val searchIndex = listOf(
        Triple("Papel de parede", "appearance", "Aparência"),
        Triple("Tema de cores / cor de destaque", "appearance", "Aparência"),
        Triple("Transparência e opacidade do vidro", "appearance", "Aparência"),
        Triple("Modo claro, escuro ou do sistema", "appearance", "Aparência"),
        Triple("Intensidade do blur", "appearance", "Aparência"),
        Triple("Cor personalizada (hexadecimal)", "appearance", "Aparência"),
        Triple("Tamanho dos ícones", "icons", "Ícones"),
        Triple("Formato dos ícones", "icons", "Ícones"),
        Triple("Pacote de ícones", "icons", "Ícones"),
        Triple("Nomes dos apps (rótulos)", "icons", "Ícones"),
        Triple("Adicionar ou remover widget", "widgets", "Widgets"),
        Triple("Relógio digital e analógico", "widgets", "Widgets"),
        Triple("Widget de clima", "widgets", "Widgets"),
        Triple("Widget do sistema (bateria, memória)", "widgets", "Widgets"),
        Triple("Altura e alinhamento dos widgets", "widgets", "Widgets"),
        Triple("Efeitos de transição (Fade, Deslizar, Zoom, Blur)", "anim", "Animações"),
        Triple("Animação ao abrir apps", "anim", "Animações"),
        Triple("Velocidade das animações", "anim", "Animações"),
        Triple("Efeito de escala ao tocar", "anim", "Animações"),
        Triple("Relógio de 24 horas", "home", "Tela inicial"),
        Triple("Data", "home", "Tela inicial"),
        Triple("Cidade do clima", "home", "Tela inicial"),
        Triple("Barra de pesquisa", "home", "Tela inicial"),
        Triple("Favoritos e dock", "home", "Tela inicial"),
        Triple("Colunas da gaveta", "drawer", "Gaveta de aplicativos"),
        Triple("Separar por letras A–Z", "drawer", "Gaveta de aplicativos"),
        Triple("Teclado ao abrir a gaveta", "drawer", "Gaveta de aplicativos"),
        Triple("Categorias personalizadas", "drawer", "Gaveta de aplicativos"),
        Triple("Definir como launcher padrão", "advanced", "Personalização avançada"),
        Triple("Restaurar configurações", "advanced", "Personalização avançada"),
        Triple("Limpar favoritos e categorias", "advanced", "Personalização avançada"),
        Triple("Sobre o Nexus Launcher, versão e build", "about", "Sobre")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        kit = SettingsKit(this, prefs)
        page = intent.getStringExtra(EXTRA_PAGE) ?: "root"

        val night = isNight()
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.isVerticalScrollBarEnabled = false
        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dpi(20), dpi(8), dpi(20), dpi(32))
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val root = FrameLayout(this)
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
            val i = ins.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        column.removeAllViews()
        when (page) {
            "appearance" -> pageAppearance()
            "icons" -> pageIcons()
            "widgets" -> pageWidgets()
            "anim" -> pageAnim()
            "home" -> pageHome()
            "drawer" -> pageDrawer()
            "advanced" -> pageAdvanced()
            "about" -> pageAbout()
            else -> pageRoot()
        }
    }

    private fun back(): () -> Unit = { finish() }

    private fun goHome(action: String? = null) {
        val i = Intent(this, HomeActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (action != null) i.putExtra(HomeActivity.ACTION_KEY, action)
        startActivity(i)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }

    // ================================================================ RAIZ

    private fun pageRoot() {
        column.addView(kit.header("Configurações", null))

        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL

        val search = EditText(this)
        search.hint = "Pesquisar nas configurações…"
        search.setSingleLine()
        search.textSize = 14f
        search.setTextColor(kit.txt)
        search.setHintTextColor(kit.sub)
        search.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        search.background = Glass.panel(this, prefs, 24f, 1.4f)
        search.setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
        search.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        search.compoundDrawablePadding = dpi(10)
        search.compoundDrawableTintList = ColorStateList.valueOf(kit.sub)
        column.addView(search, kit.lp(bottom = 14))

        // cartão do Nexus
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        kit.tint(logo)
        val nexusRow = kit.rowBase(null, "Nexus Launcher", "Versão ${versionName()}", kit.chevron()) { open("about") }
        nexusRow.addView(logo, 0, kit.lp(dpi(48), dpi(48), end = 14))
        main.addView(kit.card(nexusRow))

        main.addView(
            kit.card(
                kit.navRow(R.drawable.ic_appearance, "Aparência", "Tema, cores e transparência") { open("appearance") },
                kit.navRow(R.drawable.ic_icons, "Ícones", "Pacotes e tamanho") { open("icons") },
                kit.navRow(R.drawable.ic_widgets, "Widgets", "Personalize sua tela") { open("widgets") },
                kit.navRow(R.drawable.ic_anim, "Animações", "Transições e efeitos") { open("anim") },
                kit.navRow(R.drawable.ic_home, "Tela Inicial", "Layout e grade") { open("home") },
                kit.navRow(R.drawable.ic_drawer, "Gaveta de Aplicativos", "Organização e estilo") { open("drawer") },
                kit.navRow(R.drawable.ic_gear, "Personalização Avançada", "Mais opções") { open("advanced") }
            ).also { (it.layoutParams as LinearLayout.LayoutParams).topMargin = dpi(14) }
        )

        column.addView(main)
        column.addView(results)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().normalized().trim()
                results.removeAllViews()
                if (q.isEmpty()) {
                    main.visibility = View.VISIBLE
                    return
                }
                main.visibility = View.GONE
                val hits = searchIndex.filter { it.first.normalized().contains(q) || it.third.normalized().contains(q) }
                if (hits.isEmpty()) {
                    results.addView(kit.text("Nenhuma configuração encontrada", 14f, kit.sub), kit.lp(top = 16, start = 4))
                } else {
                    results.addView(kit.card(*hits.map { h -> kit.navRow(null, h.first, h.third) { open(h.second) } }.toTypedArray()))
                }
            }
        })
    }

    private fun open(p: String) = SettingsActivity.open(this, p)

    // ================================================================ APARÊNCIA / PERSONALIZAÇÃO

    private fun pageAppearance() {
        column.addView(kit.header("Personalização", back()))

        column.addView(kit.label("Papel de parede"))
        column.addView(wallpaperRow())

        column.addView(kit.label("Tema de cores"))
        column.addView(kit.colorDots { render() })

        column.addView(kit.label("Transparência"))
        column.addView(kit.card(kit.sliderRow("Opacidade do vidro", "panel_alpha", 5, 90, 55, "%")))

        val custom = prefs.sp.getString("accent_custom", "")?.trim().orEmpty()
        val rows = ArrayList<View>()
        rows.add(
            kit.choiceRow(
                R.drawable.ic_appearance, "Modo", "theme_mode",
                listOf("Escuro", "Claro", "Seguir o sistema"), listOf("dark", "light", "system"), "dark"
            ) { v -> prefs.applyTheme(v) }
        )
        rows.add(kit.sliderRow("Intensidade do blur (Android 12+)", "blur_radius", 0, 40, 25, ""))
        rows.add(kit.sliderRow("Escurecimento do papel de parede", "wallpaper_dim", 0, 80, 30, "%"))
        rows.add(
            kit.actionRow(null, "Cor personalizada (hexadecimal)", if (custom.isEmpty()) "Ex.: #FF4081" else custom) {
                Dialogs.promptText(this, "Cor personalizada", "#FF4081") { s ->
                    val hex = if (s.startsWith("#")) s else "#$s"
                    try {
                        Color.parseColor(hex)
                        prefs.sp.edit().putString("accent_custom", hex).apply()
                        render()
                    } catch (e: IllegalArgumentException) {
                        toast("Código de cor inválido")
                    }
                }
            }
        )
        if (custom.isNotEmpty()) {
            rows.add(kit.actionRow(null, "Remover cor personalizada", "Volta para a paleta acima") {
                prefs.sp.edit().remove("accent_custom").apply()
                render()
            })
        }
        column.addView(kit.card(*rows.toTypedArray()))

        column.addView(kit.label("Ícones"))
        column.addView(iconPackRow())
        column.addView(kit.chipGroup(
            listOf("Original" to "original", "Círculo" to "circle", "Arredondado" to "rounded"),
            "icon_shape", "original"
        ))

        column.addView(kit.label("Animações"))
        column.addView(kit.card(animTypeRow()))

        column.addView(kit.buttonRow(kit.button("Aplicar") { goHome() }))
    }

    private fun animTypeRow(): View {
        val speeds = listOf("Suave" to 100, "Rápida" to 170, "Lenta" to 60)
        fun current(): Int = speeds.indices.minByOrNull { abs(speeds[it].second - prefs.animSpeed) } ?: 0
        val tv = kit.valueText(speeds[current()].first)
        return kit.rowBase(null, "Tipo de animação", null, tv) {
            AlertDialog.Builder(this)
                .setTitle("Tipo de animação")
                .setSingleChoiceItems(speeds.map { it.first }.toTypedArray(), current()) { d, which ->
                    prefs.sp.edit().putInt("anim_speed", speeds[which].second).apply()
                    tv.text = speeds[which].first
                    d.dismiss()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun rounded(r: Float): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(r))
        }
    }

    private fun wallpaperRow(): View {
        val hsv = HorizontalScrollView(this)
        hsv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        hsv.addView(row)
        val dm = resources.displayMetrics
        for (i in WallpaperPresets.names.indices) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.outlineProvider = rounded(16f)
            iv.clipToOutline = true
            iv.contentDescription = WallpaperPresets.names[i]
            iv.setOnClickListener {
                toast("Aplicando ${WallpaperPresets.names[i]}…")
                thread(name = "nexus-wp") {
                    WallpaperHelper.setBitmap(this, WallpaperPresets.render(i, dm.widthPixels, dm.heightPixels))
                }
            }
            row.addView(iv, kit.lp(dpi(80), dpi(136), end = 10))
            thread(name = "nexus-wp-thumb") {
                val t = WallpaperPresets.render(i, 160, 272)
                runOnUiThread { iv.setImageBitmap(t) }
            }
        }
        val plus = kit.text("+", 30f, kit.txt, "sans-serif-light")
        plus.gravity = Gravity.CENTER
        plus.background = Glass.panel(this, prefs, 16f, 1.4f)
        plus.setOnClickListener { picker.launch("image/*") }
        plus.contentDescription = "Escolher da galeria"
        row.addView(plus, kit.lp(dpi(80), dpi(136)))
        return hsv
    }

    private fun iconPackRow(): View {
        val hsv = HorizontalScrollView(this)
        hsv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        hsv.addView(row)
        val packsMgr = IconPackManager(this)
        val packs = packsMgr.list()
        val entries = listOf("default" to "Padrão") + packs.map { it.pkg to it.label }
        val cells = ArrayList<LinearLayout>()
        val previews = ArrayList<ImageView>()

        fun style() {
            val cur = prefs.iconPack
            entries.forEachIndexed { i, e ->
                cells[i].background = if (e.first == cur) Glass.panel(this, prefs, 18f, 1.8f, prefs.accent)
                else Glass.panel(this, prefs, 18f, 1.3f)
            }
        }
        entries.forEach { e ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dpi(8), dpi(12), dpi(8), dpi(10))
            val iv = ImageView(this)
            cell.addView(iv, kit.lp(dpi(48), dpi(48)))
            val name = kit.text(e.second, 11f, kit.txt)
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            name.gravity = Gravity.CENTER
            cell.addView(name, kit.lp(top = 6))
            cell.setOnClickListener {
                prefs.sp.edit().putString("icon_pack", e.first).apply()
                style()
            }
            cells.add(cell)
            previews.add(iv)
            row.addView(cell, kit.lp(dpi(84), ViewGroup.LayoutParams.WRAP_CONTENT, end = 10))
        }
        style()
        thread(name = "nexus-pack-preview") {
            val app = AppRepository(this).load().firstOrNull() ?: return@thread
            entries.forEachIndexed { i, e ->
                val d = packsMgr.iconFor(e.first, app.component)
                    ?: try { packageManager.getActivityIcon(app.component) } catch (ex: Exception) { null }
                if (d != null) runOnUiThread { previews[i].setImageDrawable(d) }
            }
        }
        return hsv
    }

    // ================================================================ ÍCONES

    private fun pageIcons() {
        column.addView(kit.header("Ícones", back()))
        column.addView(
            kit.card(
                kit.sliderRow("Tamanho dos ícones (dp)", "icon_size", 40, 72, 56, ""),
                kit.switchRow(null, "Mostrar nomes dos apps", null, "labels_visible", true)
            )
        )
        column.addView(kit.label("Formato dos ícones adaptativos"))
        column.addView(kit.chipGroup(
            listOf("Original" to "original", "Círculo" to "circle", "Arredondado" to "rounded"),
            "icon_shape", "original"
        ))
        column.addView(kit.label("Pacote de ícones"))
        column.addView(iconPackRow())
        if (IconPackManager(this).list().isEmpty()) {
            column.addView(
                kit.text("Nenhum pacote instalado. O Nexus usa pacotes compatíveis com Nova, ADW e GO Launcher.", 12f, kit.sub),
                kit.lp(top = 10, start = 4)
            )
        }
    }

    // ================================================================ WIDGETS

    private fun pageWidgets() {
        column.addView(kit.header("Widgets", back()))
        column.addView(widgetTabs())
        when (widgetTab) {
            0 -> tabClock()
            1 -> tabWeather()
            2 -> tabSystem()
            else -> tabCustom()
        }
        column.addView(kit.label("Tamanho e posição"))
        column.addView(
            kit.card(
                kit.sliderRow("Altura da área de widgets do Android (dp)", "widget_height", 100, 320, 160, ""),
                kit.choiceRow(
                    null, "Alinhamento do relógio e clima", "home_align",
                    listOf("Centralizado", "À esquerda"), listOf("center", "start"), "center"
                ),
                kit.switchRow(null, "Mostrar área de widgets do Android", null, "show_widget_area", true)
            )
        )
    }

    private fun widgetTabs(): View {
        val names = listOf("Relógio", "Clima", "Sistema", "Personalizado")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        names.forEachIndexed { i, n ->
            val sel = i == widgetTab
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setOnClickListener { widgetTab = i; render() }
            col.addView(
                kit.text(n, 14f, if (sel) kit.txt else kit.sub, if (sel) "sans-serif-medium" else "sans-serif"),
                kit.lp(top = 8, bottom = 8)
            )
            val line = View(this)
            line.setBackgroundColor(if (sel) kit.accent else Color.TRANSPARENT)
            col.addView(line, kit.lp(h = dpi(2)))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    private fun clockPreview(style: String, big: Boolean = false): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        fun tc(pattern: String, size: Float): TextClock {
            val t = TextClock(this)
            t.format24Hour = pattern
            t.format12Hour = pattern
            t.textSize = size
            t.setTextColor(kit.txt)
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            return t
        }
        fun dateText(): TextView {
            val t = kit.text(datePreview(), if (big) 13f else 11f, kit.sub)
            t.gravity = Gravity.CENTER
            return t
        }
        when (style) {
            "analog", "analog2" -> {
                val a = AnalogClockView(this)
                a.tint = kit.txt
                a.secondColor = kit.accent
                a.detailed = style == "analog2"
                box.addView(a, kit.lp(dpi(84), dpi(84)))
            }
            "stacked" -> box.addView(tc("HH\nmm", 34f))
            "compact" -> {
                box.addView(tc("HH:mm", 26f))
                box.addView(dateText())
            }
            else -> {
                box.addView(tc("HH:mm", if (big) 54f else 38f))
                box.addView(dateText())
            }
        }
        return box
    }

    private fun datePreview(): String {
        val now = java.util.Calendar.getInstance()
        val loc = java.util.Locale.getDefault()
        val day = java.text.SimpleDateFormat("EEE", loc).format(now.time).trimEnd('.').replaceFirstChar { it.uppercase() }
        val mon = java.text.SimpleDateFormat("MMM", loc).format(now.time).trimEnd('.').replaceFirstChar { it.uppercase() }
        val d = now.get(java.util.Calendar.DAY_OF_MONTH)
        return if (loc.language == "pt") "$day, $d de $mon." else "$day, $d $mon"
    }

    private fun clockCard(key: String, selected: String, big: Boolean, heightDp: Int): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.setPadding(dpi(8), dpi(10), dpi(8), dpi(10))
        card.background =
            if (key == selected) Glass.panel(this, prefs, 22f, 1.8f, prefs.accent) else Glass.panel(this, prefs, 22f, 1.4f)
        card.addView(clockPreview(key, big), kit.lp(h = dpi(heightDp)))
        card.setOnClickListener { pendingClockStyle = key; render() }
        return card
    }

    private fun tabClock() {
        val selected = pendingClockStyle ?: prefs.clockStyle
        column.addView(kit.label("Escolha o estilo do relógio"))
        column.addView(clockCard("big", selected, true, 110), kit.lp(top = 4))
        fun pair(a: String, b: String): View {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val pa = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            pa.setMargins(0, dpi(10), dpi(5), 0)
            val pb = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            pb.setMargins(dpi(5), dpi(10), 0, 0)
            row.addView(clockCard(a, selected, false, 92), pa)
            row.addView(clockCard(b, selected, false, 92), pb)
            return row
        }
        column.addView(pair("compact", "analog"))
        column.addView(pair("stacked", "analog2"))
        column.addView(kit.buttonRow(
            kit.button("Adicionar Widget") {
                prefs.sp.edit().putString("clock_style", selected).putBoolean("show_clock", true).apply()
                pendingClockStyle = null
                toast("Relógio atualizado na tela inicial")
                render()
            }
        ))
        val remove = kit.text("Remover relógio da tela inicial", 13f, kit.sub)
        remove.gravity = Gravity.CENTER
        remove.setPadding(0, dpi(14), 0, dpi(6))
        remove.setOnClickListener {
            prefs.sp.edit().putBoolean("show_clock", false).apply()
            toast("Relógio ocultado")
        }
        column.addView(remove, kit.lp())
    }

    private fun weatherCityLabel(): String {
        val c = prefs.weatherCity.trim()
        return if (c.isEmpty()) "Automática (localização aproximada pela rede)" else c
    }

    private fun askCity() {
        Dialogs.promptText(
            this, "Cidade do clima", "Ex.: São Paulo",
            "Automático", {
                prefs.sp.edit().putString("weather_city", "").remove("weather_cache").apply()
                render()
            }
        ) { c ->
            prefs.sp.edit().putString("weather_city", c).remove("weather_cache").apply()
            render()
        }
    }

    private fun tabWeather() {
        column.addView(kit.label("Clima"))
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_w_cloud)
        kit.tint(icon)
        val temp = kit.text("--°C", 28f, kit.txt, "sans-serif-light")
        val desc = kit.text("Buscando clima…", 12f, kit.txt)
        val place = kit.text("", 11f, kit.sub)
        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.addView(temp)
        info.addView(desc)
        info.addView(place)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dpi(20), dpi(14), dpi(20), dpi(14))
        card.background = Glass.panel(this, prefs, 26f, 1.4f)
        card.addView(icon, kit.lp(dpi(38), dpi(38), end = 14))
        card.addView(info)
        column.addView(card, kit.lp(top = 4))

        fun show(i: WeatherRepo.Info) {
            val d = WeatherRepo.describe(i.code)
            icon.setImageResource(d.first)
            temp.text = "${i.temp}°C"
            desc.text = d.second
            place.text = i.place
        }
        val q = prefs.weatherCity.trim()
        val cached = WeatherRepo.cached(prefs)
        if (cached != null && cached.q == q) show(cached)
        thread(name = "nexus-weather-preview") {
            val i = WeatherRepo.refresh(prefs)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (i != null) show(i) else if (cached == null) desc.text = "Sem dados: verifique a internet ou o nome da cidade"
            }
        }

        column.addView(kit.card(
            kit.actionRow(null, "Cidade do clima", weatherCityLabel()) { askCity() }
        ), kit.lp(top = 14))
        column.addView(kit.buttonRow(
            kit.button("Adicionar Widget") {
                prefs.sp.edit().putBoolean("show_weather", true).apply()
                toast("Clima ativado na tela inicial")
            },
            kit.button("Remover") {
                prefs.sp.edit().putBoolean("show_weather", false).apply()
                toast("Clima ocultado")
            }
        ))
        column.addView(
            kit.text("Dados reais do Open-Meteo, atualizados a cada 20 minutos. No modo automático, a localização é aproximada pelo seu IP (sem permissão de GPS). Exige internet.", 12f, kit.sub),
            kit.lp(top = 10, start = 4)
        )
    }

    private fun tabSystem() {
        column.addView(kit.label("Painel do sistema"))
        val (pct, charging) = SysInfo.battery(this)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpi(18), dpi(16), dpi(18), dpi(16))
        card.background = Glass.panel(this, prefs, 24f, 1.4f)
        card.addView(kit.text("Bateria · $pct%" + (if (charging) " · carregando" else ""), 14f))
        card.addView(kit.text(SysInfo.storage(this), 12f, kit.sub), kit.lp(top = 8))
        card.addView(kit.text(SysInfo.ram(this), 12f, kit.sub), kit.lp(top = 2))
        card.addView(kit.text(SysInfo.device(), 12f, kit.sub), kit.lp(top = 2))
        column.addView(card, kit.lp(top = 4))
        column.addView(kit.buttonRow(
            kit.button("Adicionar Widget") {
                prefs.sp.edit().putBoolean("show_info", true).apply()
                toast("Painel do sistema ativado")
            },
            kit.button("Remover") {
                prefs.sp.edit().putBoolean("show_info", false).apply()
                toast("Painel do sistema ocultado")
            }
        ))
    }

    private fun tabCustom() {
        column.addView(kit.label("Widgets de outros aplicativos"))
        val n = prefs.widgetIds.size
        column.addView(kit.card(
            kit.rowBase(R.drawable.ic_widgets, "Widgets do Android adicionados", "$n na tela inicial", null, null)
        ), kit.lp(top = 4))
        column.addView(kit.buttonRow(
            kit.button("Adicionar Widget") { goHome("add_widget") },
            kit.button("Remover") { goHome("remove_widget") }
        ))
        column.addView(
            kit.text("Qualquer widget instalado no aparelho pode ser adicionado. Na tela inicial, segure um widget para removê-lo.", 12f, kit.sub),
            kit.lp(top = 10, start = 4)
        )
    }

    // ================================================================ ANIMAÇÕES

    private fun pageAnim() {
        column.addView(kit.header("Animações", back()))

        val premium = kit.rowBase(R.drawable.ic_anim, "Animação Premium", "Transições suaves e fluidas (toque para testar)", null, null)
        val check = ImageView(this)
        check.setImageResource(R.drawable.ic_check)
        kit.tint(check, Color.parseColor("#34C759"))
        check.setPadding(dpi(5), dpi(5), dpi(5), dpi(5))
        val ring = android.graphics.drawable.GradientDrawable()
        ring.shape = android.graphics.drawable.GradientDrawable.OVAL
        ring.setColor(Color.TRANSPARENT)
        ring.setStroke(dpi(2), Color.parseColor("#34C759"))
        check.background = ring
        premium.addView(check, LinearLayout.LayoutParams(dpi(28), dpi(28)))
        val premiumCard = kit.card(premium)
        premiumCard.isClickable = true
        premiumCard.setOnClickListener {
            premiumCard.animate().scaleX(0.93f).scaleY(0.93f).alpha(0.6f).setDuration(prefs.dur(180)).withEndAction {
                premiumCard.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(prefs.dur(260)).start()
            }.start()
        }
        column.addView(premiumCard)

        column.addView(kit.label("Efeitos de transição (gaveta)"))
        column.addView(kit.chipGroup(
            listOf("Fade" to "fade", "Deslizar" to "slide", "Zoom" to "zoom", "Blur" to "blur"),
            "drawer_anim", "slide"
        ))

        val launchOn = prefs.launchAnim != "none"
        val launchSwitch = kit.switchRow(null, "Animação ao Abrir Apps", null, "launch_enabled_dummy", launchOn) { on ->
            prefs.sp.edit().remove("launch_enabled_dummy").apply()
            if (on) {
                val prev = prefs.sp.getString("launch_prev", "zoom") ?: "zoom"
                prefs.sp.edit().putString("launch_anim", if (prev == "none") "zoom" else prev).apply()
            } else {
                prefs.sp.edit().putString("launch_prev", prefs.launchAnim).putString("launch_anim", "none").apply()
            }
            render()
        }
        column.addView(kit.card(
            launchSwitch,
            kit.choiceRow(
                null, "Estilo ao abrir apps", "launch_anim",
                listOf("Zoom a partir do ícone", "Revelar", "Esmaecer", "Nenhuma"),
                listOf("zoom", "reveal", "fade", "none"), "zoom"
            ) { render() },
            kit.sliderRow("Velocidade das animações", "anim_speed", 50, 200, 100, "%"),
            kit.switchRow(null, "Efeito de escala ao tocar nos ícones", null, "press_scale", true),
            kit.switchRow(null, "Transições com blur", "Requer Android 12 ou superior", "blur_transitions", true)
        ), kit.lp(top = 14))
    }

    // ================================================================ TELA INICIAL

    private fun pageHome() {
        column.addView(kit.header("Tela inicial", back()))
        column.addView(kit.label("Relógio e data"))
        column.addView(kit.card(
            kit.switchRow(null, "Mostrar relógio", null, "show_clock", true),
            kit.choiceRow(
                null, "Estilo do relógio", "clock_style",
                listOf("Digital", "Compacto", "Empilhado", "Analógico", "Analógico detalhado"),
                listOf("big", "compact", "stacked", "analog", "analog2"), "big"
            ),
            kit.switchRow(null, "Relógio de 24 horas", null, "clock_24h", true),
            kit.switchRow(null, "Mostrar data", null, "show_date", true),
            kit.choiceRow(
                null, "Alinhamento", "home_align",
                listOf("Centralizado", "À esquerda"), listOf("center", "start"), "center"
            )
        ))
        column.addView(kit.label("Clima e sistema"))
        column.addView(kit.card(
            kit.switchRow(null, "Mostrar clima", null, "show_weather", true),
            kit.actionRow(null, "Cidade do clima", weatherCityLabel()) { askCity() },
            kit.switchRow(null, "Mostrar bateria e informações do sistema", null, "show_info", false)
        ))
        column.addView(kit.label("Atalhos"))
        column.addView(kit.card(
            kit.switchRow(null, "Mostrar barra de pesquisa", null, "show_search", true),
            kit.switchRow(null, "Mostrar favoritos (grade)", "Segure um app na gaveta para favoritar", "show_favs", true),
            kit.switchRow(null, "Mostrar dock", "Segure um app na gaveta para adicionar ao dock", "show_dock", true),
            kit.actionRow(null, "Restaurar dock padrão", "Telefone, Mensagens e Câmera") {
                prefs.resetDock()
                toast("Dock restaurado")
            }
        ))
    }

    // ================================================================ GAVETA

    private fun pageDrawer() {
        column.addView(kit.header("Gaveta de Aplicativos", back()))
        column.addView(kit.card(
            kit.sliderRow("Colunas", "drawer_columns", 3, 6, 4, ""),
            kit.switchRow(null, "Separar por letras (A–Z)", null, "letter_headers", true),
            kit.switchRow(null, "Abrir teclado ao abrir a gaveta", null, "drawer_autofocus", false)
        ))
        column.addView(kit.label("Categorias"))
        column.addView(kit.card(
            kit.actionRow(null, "Nova categoria", "Depois, segure um app e escolha “Categoria…”") {
                Dialogs.promptText(this, "Nova categoria", "Nome da categoria") { n ->
                    prefs.addCategory(n)
                    toast("Categoria criada")
                    render()
                }
            },
            kit.actionRow(null, "Gerenciar categorias", "${prefs.categories.size} criada(s) — toque para excluir") {
                manageCategories()
            }
        ))
        column.addView(
            kit.text("Jogos, Redes e Ferramentas são organizadas automaticamente quando o app informa sua categoria.", 12f, kit.sub),
            kit.lp(top = 10, start = 4)
        )
    }

    private fun manageCategories() {
        val cats = prefs.categories
        if (cats.isEmpty()) {
            toast("Nenhuma categoria criada ainda")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Excluir categoria")
            .setItems(cats.toTypedArray()) { _, i ->
                AlertDialog.Builder(this)
                    .setMessage("Excluir “${cats[i]}”? Os apps continuam instalados.")
                    .setPositiveButton("Excluir") { _, _ -> prefs.removeCategory(cats[i]); render() }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    // ================================================================ AVANÇADO

    private fun pageAdvanced() {
        column.addView(kit.header("Personalização Avançada", back()))
        column.addView(kit.card(
            kit.actionRow(R.drawable.ic_home, "Definir como launcher padrão", "Abre a tela do sistema para escolher o Nexus como Home") {
                requestDefaultHome()
            },
            kit.actionRow(null, "Limpar favoritos, dock e categorias", null) {
                confirm("Limpar todos os favoritos, o dock e as categorias?") {
                    prefs.resetFavoritesAndCategories()
                    toast("Limpo")
                }
            },
            kit.actionRow(null, "Restaurar todas as configurações", "Também remove os widgets da tela inicial") {
                confirm("Restaurar todas as configurações e remover os widgets?") {
                    prefs.resetAll()
                    toast("Configurações restauradas")
                    recreate()
                }
            },
            kit.actionRow(null, "Sugerir papel de parede Nexus novamente", null) {
                prefs.sp.edit().putBoolean("wallpaper_asked", false).apply()
                toast("A sugestão aparece na próxima vez que a tela inicial abrir")
            }
        ))
        column.addView(kit.card(
            kit.navRow(null, "Sobre o Nexus Launcher", "Versão ${versionName()}") { open("about") }
        ), kit.lp(top = 14))
    }

    private fun confirm(msg: String, action: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("Confirmar") { _, _ -> action() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun requestDefaultHome() {
        val rm = getSystemService(RoleManager::class.java)
        try {
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (rm.isRoleHeld(RoleManager.ROLE_HOME)) toast("O Nexus já é o launcher padrão")
                else roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
            } else {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ================================================================ SOBRE

    private fun pageAbout() {
        column.addView(kit.header("Sobre o Launcher", back()))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        kit.tint(logo)
        box.addView(logo, kit.lp(dpi(96), dpi(96), top = 16))
        val name = kit.text("NEXUS LAUNCHER", 20f, kit.txt, "sans-serif-medium")
        name.letterSpacing = 0.18f
        box.addView(name, kit.lp(top = 12))
        box.addView(kit.text("Versão ${versionName()}", 13f, kit.sub), kit.lp(top = 4))
        column.addView(box)

        val build = try {
            PackageInfoCompat.getLongVersionCode(packageManager.getPackageInfo(packageName, 0)).toString()
        } catch (e: Exception) {
            "—"
        }
        column.addView(kit.card(
            kit.infoRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"),
            kit.infoRow("Desenvolvedor", "Nexus Dev"),
            kit.infoRow("Build", build),
            kit.infoRow("Aparelho", "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}")
        ), kit.lp(top = 22))
        val foot = kit.text("Feito com ♥ para você.", 12f, kit.sub)
        foot.gravity = Gravity.CENTER
        column.addView(foot, kit.lp(top = 18))
    }
}
