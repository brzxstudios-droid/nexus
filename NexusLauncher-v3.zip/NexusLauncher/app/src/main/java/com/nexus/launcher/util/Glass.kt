package com.nexus.launcher.util

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils
import com.nexus.launcher.data.Prefs

/** Painéis "vidro": preenchimento translúcido com brilho no topo e borda luminosa. */
object Glass {
    fun panel(ctx: Context, prefs: Prefs, radiusDp: Float, density: Float = 1f, stroke: Int? = null): GradientDrawable {
        val night = ctx.isNight()
        val a = (prefs.panelAlpha / 100f * density).coerceIn(0.04f, 0.95f)
        val base = if (night) Color.BLACK else Color.WHITE
        val fill = ColorUtils.setAlphaComponent(base, (a * 255).toInt())
        val sheen = Color.argb(if (night) 34 else 90, 255, 255, 255)
        val top = ColorUtils.compositeColors(sheen, fill)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, fill)).apply {
            cornerRadius = ctx.dp(radiusDp)
            setStroke(
                ctx.dpi(1),
                stroke ?: if (night) Color.argb(60, 255, 255, 255) else Color.argb(50, 0, 0, 0)
            )
        }
    }

    fun fill(ctx: Context, color: Int, radiusDp: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = ctx.dp(radiusDp)
        }
}
