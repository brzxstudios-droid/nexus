package com.nexus.launcher.ui.home

import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.nexus.launcher.R
import com.nexus.launcher.data.AppInfo
import com.nexus.launcher.data.AppRepository
import com.nexus.launcher.data.IconLoader
import com.nexus.launcher.data.IconPackManager
import com.nexus.launcher.data.Prefs
import com.nexus.launcher.data.WeatherRepo
import com.nexus.launcher.settings.SettingsActivity
import com.nexus.launcher.ui.widget.AnalogClockView
import com.nexus.launcher.util.Dialogs
import com.nexus.launcher.util.Glass
import com.nexus.launcher.util.SysInfo
import com.nexus.launcher.util.WallpaperHelper
import com.nexus.launcher.util.WallpaperPresets
import com.nexus.launcher.util.dp
import com.nexus.launcher.util.dpi
import com.nexus.launcher.util.isNight
import com.nexus.launcher.util.normalized
import com.nexus.launcher.util.themeColor
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class HomeActivity : AppCompatActivity() {

    companion object {
        const val ACTION_KEY = "nexus_action"
        private const val REQ_BIND = 201
        private const val REQ_CONFIG = 202
        private const val FILTER_ALL = "\u0001all"
        private const val WEATHER_TTL = 20 * 60 * 1000L
    }

    private lateinit var prefs: Prefs
    private lateinit var repo: AppRepository
    private lateinit var loader: IconLoader

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: View
    private lateinit var clockBlock: LinearLayout
    private lateinit var clock: TextClock
    private lateinit var analogClock: AnalogClockView
    private lateinit var date: TextView
    private lateinit var weatherCard: LinearLayout
    private lateinit var weatherIcon: ImageView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherDesc: TextView
    private lateinit var weatherCity: TextView
    private lateinit var infoPanel: View
    private lateinit var batteryText: TextView
    private lateinit var batteryBar: ProgressBar
    private lateinit var storageText: TextView
    private lateinit var ramText: TextView
    private lateinit var deviceText: TextView
    private lateinit var widgetPanel: FrameLayout
    private lateinit var widgetRow: LinearLayout
    private lateinit var searchBar: LinearLayout
    private lateinit var searchIcon: ImageView
    private lateinit var btnMic: ImageView
    private lateinit var btnScan: ImageView
    private lateinit var favHint: TextView
    private lateinit var favPager: ViewPager2
    private lateinit var dots: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: FrameLayout
    private lateinit var drawerPanel: View
    private lateinit var drawerHandleArea: View
    private lateinit var searchInput: EditText
    private lateinit var tabRow: LinearLayout
    private lateinit var recycler: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var alphaIndex: LinearLayout

    private lateinit var adapter: AppAdapter
    private lateinit var favAdapter: FavPagerAdapter
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private lateinit var wallpaperPicker: ActivityResultLauncher<String>
    private lateinit var swipeDetector: GestureDetector

    private val main = Handler(Looper.getMainLooper())
    private var apps: List<AppInfo> = emptyList()
    private var filter = FILTER_ALL
    private var drawerOpen = false
    private var pendingWidgetId = -1
    private var lastWidgetSig = ""
    private var lastSpan = -1
    private var currentBlur = 0f
    private var blurAnim: ValueAnimator? = null
    private var weatherBusy = false
    private var swipeAllowed = false
    private val swipeRect = Rect()

    private val reloadRunnable = Runnable { reloadApps() }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i != null) updateBattery(i)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            main.removeCallbacks(reloadRunnable)
            main.postDelayed(reloadRunnable, 500)
        }
    }

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            updateDate()
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_home)

        prefs = Prefs(this)
        repo = AppRepository(this)
        loader = IconLoader(this, prefs, IconPackManager(this))
        widgetHost = AppWidgetHost(this, Prefs.WIDGET_HOST_ID)
        awm = AppWidgetManager.getInstance(this)

        bindViews()
        setupInsets()
        setupDrawer()
        setupFavorites()
        setupGestures()
        setupHomeClicks()

        wallpaperPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) WallpaperHelper.set(this, uri)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) closeDrawer()
            }
        })

        ContextCompat.registerReceiver(
            this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )?.let { updateBattery(it) }

        val pf = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, pf, ContextCompat.RECEIVER_NOT_EXPORTED)

        val tf = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        ContextCompat.registerReceiver(this, timeReceiver, tf, ContextCompat.RECEIVER_NOT_EXPORTED)

        reloadApps()
        if (savedInstanceState == null) {
            handleIntent(intent)
            root.post { offerWallpaper() }
        }
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        applyPrefs()
        refreshSystemInfo()
        updateDate()
    }

    override fun onStop() {
        super.onStop()
        try { widgetHost.stopListening() } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        try { unregisterReceiver(timeReceiver) } catch (e: Exception) { }
        loader.shutdown()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Deslizar para cima em qualquer ponto livre da tela inicial abre a gaveta. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen && ::swipeDetector.isInitialized) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                val onWidgets = widgetPanel.visibility == View.VISIBLE &&
                    widgetPanel.getGlobalVisibleRect(swipeRect) &&
                    swipeRect.contains(ev.rawX.toInt(), ev.rawY.toInt())
                swipeAllowed = !onWidgets
            }
            if (swipeAllowed) swipeDetector.onTouchEvent(ev)
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val action = i.getStringExtra(ACTION_KEY)
        i.removeExtra(ACTION_KEY)
        when (action) {
            "add_widget" -> root.post { showWidgetPicker() }
            "remove_widget" -> root.post { showRemoveWidget() }
            else -> if (i.hasCategory(Intent.CATEGORY_HOME) && drawerOpen) closeDrawer()
        }
    }

    // ---------------------------------------------------------------- setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        homeLayer = findViewById(R.id.homeLayer)
        clockBlock = findViewById(R.id.clockBlock)
        clock = findViewById(R.id.clock)
        analogClock = findViewById(R.id.analogClock)
        date = findViewById(R.id.date)
        weatherCard = findViewById(R.id.weatherCard)
        weatherIcon = findViewById(R.id.weatherIcon)
        weatherTemp = findViewById(R.id.weatherTemp)
        weatherDesc = findViewById(R.id.weatherDesc)
        weatherCity = findViewById(R.id.weatherCity)
        infoPanel = findViewById(R.id.infoPanel)
        batteryText = findViewById(R.id.batteryText)
        batteryBar = findViewById(R.id.batteryBar)
        storageText = findViewById(R.id.storageText)
        ramText = findViewById(R.id.ramText)
        deviceText = findViewById(R.id.deviceText)
        widgetPanel = findViewById(R.id.widgetPanel)
        widgetRow = findViewById(R.id.widgetRow)
        searchBar = findViewById(R.id.searchBar)
        searchIcon = findViewById(R.id.searchIcon)
        btnMic = findViewById(R.id.btnMic)
        btnScan = findViewById(R.id.btnScan)
        favHint = findViewById(R.id.favHint)
        favPager = findViewById(R.id.favPager)
        dots = findViewById(R.id.dots)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        drawerPanel = findViewById(R.id.drawerPanel)
        drawerHandleArea = findViewById(R.id.drawerHandleArea)
        searchInput = findViewById(R.id.searchInput)
        tabRow = findViewById(R.id.tabRow)
        recycler = findViewById(R.id.recycler)
        emptyView = findViewById(R.id.emptyView)
        alphaIndex = findViewById(R.id.alphaIndex)
    }

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.ime() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupHomeClicks() {
        clock.setOnClickListener { openClockApp() }
        analogClock.setOnClickListener { openClockApp() }
        date.setOnClickListener { openCalendarApp() }
        weatherCard.setOnClickListener { onWeatherTap() }
        weatherCard.setOnLongClickListener { askWeatherCity(); true }
        btnMic.setOnClickListener { voiceSearch() }
        btnScan.setOnClickListener { scanSearch() }
        searchBar.setOnClickListener { openDrawer(true) }
    }

    private fun setupFavorites() {
        favAdapter = FavPagerAdapter(loader, { a, v -> launchApp(a, v) }, { a, v -> showAppMenu(a, v) })
        favPager.adapter = favAdapter
        favPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
            }
        })
    }

    private fun setupDrawer() {
        adapter = AppAdapter(loader, { a, v -> launchApp(a, v) }, { a, v -> showAppMenu(a, v) })
        recycler.adapter = adapter
        recycler.itemAnimator = null

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refreshDrawer()
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH) {
                val first = adapter.rows.firstOrNull { it is Row.App } as? Row.App
                val q = searchInput.text.toString().trim()
                if (first != null) launchApp(first.info, searchInput)
                else if (q.isNotEmpty()) webSearch(q)
                true
            } else false
        }
        emptyView.setOnClickListener {
            val q = searchInput.text.toString().trim()
            if (q.isNotEmpty()) webSearch(q)
        }

        val handleGestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { closeDrawer(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy > 600) { closeDrawer(); return true }
                return false
            }
        })
        drawerHandleArea.setOnTouchListener { _, ev -> handleGestures.onTouchEvent(ev); true }

        // Índice alfabético A–Z (duas linhas), como na referência
        val letters = ('A'..'Z').toList()
        listOf(letters.subList(0, 13), letters.subList(13, 26)).forEach { part ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (ch in part) {
                val tv = TextView(this)
                tv.text = ch.toString()
                tv.textSize = 10f
                tv.gravity = Gravity.CENTER
                tv.setPadding(0, dpi(6), 0, dpi(6))
                tv.alpha = 0.7f
                tv.setTextColor(themeColor(android.R.attr.textColorPrimary))
                tv.setOnClickListener { scrollToLetter(ch) }
                row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            alphaIndex.addView(row, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun setupGestures() {
        swipeDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > dpi(90) && vy < -700 && abs(vx) < abs(vy)) {
                    openDrawer()
                    return true
                }
                return false
            }
        })
        val longPress = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                homeLayer.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showHomeMenu()
            }
        })
        homeLayer.setOnTouchListener { _, ev -> longPress.onTouchEvent(ev); true }
    }

    private fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            if (prefs.pressScale) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        view.animate().scaleX(0.88f).scaleY(0.88f).setDuration(prefs.dur(90)).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        view.animate().scaleX(1f).scaleY(1f).setDuration(prefs.dur(140)).start()
                }
            }
            false
        }
    }

    // ---------------------------------------------------------------- preferências / aparência

    private fun applyPrefs() {
        val night = isNight()
        val accent = prefs.accent
        val txt = themeColor(android.R.attr.textColorPrimary)

        val base = if (night) Color.BLACK else Color.WHITE
        root.setBackgroundColor(ColorUtils.setAlphaComponent(base, prefs.wallpaperDim * 255 / 100))
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }

        // relógio
        val style = prefs.clockStyle
        val analog = style == "analog" || style == "analog2"
        clock.visibility = if (analog) View.GONE else View.VISIBLE
        analogClock.visibility = if (analog) View.VISIBLE else View.GONE
        analogClock.tint = txt
        analogClock.secondColor = accent
        analogClock.detailed = style == "analog2"
        val clockPattern = when {
            style == "stacked" && prefs.clock24 -> "HH\nmm"
            style == "stacked" -> "hh\nmm"
            prefs.clock24 -> "HH:mm"
            else -> "hh:mm"
        }
        clock.format24Hour = clockPattern
        clock.format12Hour = clockPattern
        clock.setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            when (style) { "compact" -> 52f; "stacked" -> 84f; else -> 96f }
        )
        clock.setLineSpacing(0f, 0.9f)

        val center = prefs.homeAlign == "center"
        clockBlock.gravity = if (center) Gravity.CENTER_HORIZONTAL else Gravity.START
        (weatherCard.layoutParams as LinearLayout.LayoutParams).gravity =
            if (center) Gravity.CENTER_HORIZONTAL else Gravity.START
        weatherCard.requestLayout()

        clockBlock.visibility = if (prefs.showClock) View.VISIBLE else View.GONE
        date.visibility = if (prefs.showDate) View.VISIBLE else View.GONE
        infoPanel.visibility = if (prefs.showInfo) View.VISIBLE else View.GONE
        searchBar.visibility = if (prefs.showSearch) View.VISIBLE else View.GONE
        dock.visibility = if (prefs.showDock) View.VISIBLE else View.GONE

        // painéis de vidro
        weatherCard.background = Glass.panel(this, prefs, 26f, 1.0f)
        weatherIcon.imageTintList = ColorStateList.valueOf(txt)
        infoPanel.background = Glass.panel(this, prefs, 24f)
        widgetPanel.background = Glass.panel(this, prefs, 24f)
        widgetPanel.clipToOutline = true
        searchBar.background = Glass.panel(this, prefs, 27f, 1.0f)
        searchIcon.imageTintList = ColorStateList.valueOf(txt)
        btnMic.imageTintList = ColorStateList.valueOf(txt)
        btnScan.imageTintList = ColorStateList.valueOf(txt)
        favHint.setTextColor(txt)
        drawer.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (night) intArrayOf(Color.argb(240, 18, 18, 20), Color.argb(245, 5, 5, 5))
            else intArrayOf(Color.argb(242, 246, 246, 249), Color.argb(245, 232, 232, 238))
        )
        searchInput.background = Glass.panel(this, prefs, 25f, 1.3f)
        searchInput.compoundDrawableTintList = ColorStateList.valueOf(ColorUtils.setAlphaComponent(txt, 170))
        drawerPanel.background = null
        findViewById<View>(R.id.drawerHandle).background =
            Glass.fill(this, ColorUtils.setAlphaComponent(txt, 70), 2f)

        batteryBar.progressTintList = ColorStateList.valueOf(accent)
        batteryBar.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(60, 128, 128, 128))

        val lp = widgetPanel.layoutParams
        lp.height = dpi(prefs.widgetHeight)
        widgetPanel.layoutParams = lp

        adapter.iconPx = dpi(prefs.iconSize)
        adapter.showLabels = prefs.showLabels
        adapter.pressScale = prefs.pressScale
        adapter.accent = accent
        adapter.textColor = txt

        val span = prefs.drawerColumns
        if (span != lastSpan) {
            lastSpan = span
            val glm = GridLayoutManager(this, span)
            glm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int) = if (adapter.isHeader(position)) span else 1
            }
            recycler.layoutManager = glm
        }

        rebuildTabs()
        refreshDrawer()
        refreshFavorites()
        refreshDock()
        restoreWidgets()
        refreshWeather()
    }

    private fun refreshSystemInfo() {
        storageText.text = SysInfo.storage(this)
        ramText.text = SysInfo.ram(this)
        deviceText.text = SysInfo.device()
    }

    /** Data no formato da referência: "Qua, 18 de Nov." */
    private fun updateDate() {
        val now = Calendar.getInstance()
        val loc = Locale.getDefault()
        val day = SimpleDateFormat("EEE", loc).format(now.time).trimEnd('.').replaceFirstChar { it.uppercase() }
        val mon = SimpleDateFormat("MMM", loc).format(now.time).trimEnd('.').replaceFirstChar { it.uppercase() }
        val d = now.get(Calendar.DAY_OF_MONTH)
        date.text = if (loc.language == "pt") "$day, $d de $mon." else "$day, $d $mon"
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = "Bateria · $pct%" + (if (charging) " · carregando" else "")
        batteryBar.progress = pct
    }

    private fun offerWallpaper() {
        if (prefs.sp.getBoolean("wallpaper_asked", false)) return
        prefs.sp.edit().putBoolean("wallpaper_asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Papel de parede Nexus")
            .setMessage("Aplicar o papel de parede escuro e futurista do Nexus? Você pode trocar depois em Configurações > Aparência.")
            .setPositiveButton("Aplicar") { _, _ ->
                val dm = resources.displayMetrics
                thread(name = "nexus-wp-render") {
                    WallpaperHelper.setBitmap(this, WallpaperPresets.render(0, dm.widthPixels, dm.heightPixels))
                }
            }
            .setNegativeButton("Agora não", null)
            .show()
    }

    // ---------------------------------------------------------------- clima

    private fun refreshWeather(force: Boolean = false) {
        if (!prefs.showWeather) {
            weatherCard.visibility = View.GONE
            return
        }
        weatherCard.visibility = View.VISIBLE
        val q = prefs.weatherCity.trim()
        val cached = WeatherRepo.cached(prefs)
        val fresh = cached != null && cached.q == q
        if (fresh && cached != null) {
            showWeather(cached)
        } else {
            weatherIcon.setImageResource(R.drawable.ic_w_cloud)
            weatherTemp.text = "--°C"
            weatherDesc.text = "Buscando clima…"
            weatherCity.text = if (q.isEmpty()) "Localização automática" else q
        }
        val stale = !fresh || (cached != null && System.currentTimeMillis() - cached.at > WEATHER_TTL)
        if ((stale || force) && !weatherBusy) {
            weatherBusy = true
            thread(name = "nexus-weather") {
                val info = WeatherRepo.refresh(prefs)
                runOnUiThread {
                    weatherBusy = false
                    if (isDestroyed) return@runOnUiThread
                    if (info != null) {
                        showWeather(info)
                    } else if (!fresh) {
                        weatherIcon.setImageResource(R.drawable.ic_w_cloud)
                        weatherTemp.text = "Sem dados"
                        weatherDesc.text = "Sem internet ou cidade não encontrada"
                        weatherCity.text = "Toque para tentar de novo"
                    }
                }
            }
        }
    }

    private fun showWeather(info: WeatherRepo.Info) {
        val d = WeatherRepo.describe(info.code)
        weatherIcon.setImageResource(d.first)
        weatherTemp.text = "${info.temp}°C"
        weatherDesc.text = d.second
        weatherCity.text = info.place
    }

    private fun onWeatherTap() {
        Toast.makeText(this, "Atualizando clima… (segure para mudar a cidade)", Toast.LENGTH_SHORT).show()
        refreshWeather(true)
    }

    private fun askWeatherCity() {
        Dialogs.promptText(
            this, "Cidade do clima", "Ex.: São Paulo",
            "Automático", {
                prefs.sp.edit().putString("weather_city", "").remove("weather_cache").apply()
                refreshWeather(true)
            }
        ) { c ->
            prefs.sp.edit().putString("weather_city", c).remove("weather_cache").apply()
            refreshWeather(true)
        }
    }

    private fun openClockApp() {
        try {
            startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "App de relógio não encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCalendarApp() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "App de calendário não encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun voiceSearch() {
        try {
            startActivity(Intent(RecognizerIntent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Pesquisa por voz indisponível neste aparelho", Toast.LENGTH_SHORT).show()
        }
    }

    /** Pesquisa por imagem: abre o Google Lens se existir; senão, a câmera. */
    private fun scanSearch() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("google://lens")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                Toast.makeText(this, "Nenhum app de câmera disponível", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------- apps

    private fun reloadApps() {
        thread(name = "nexus-apps") {
            val list = repo.load()
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = list
                initDefaults()
                rebuildTabs()
                refreshDrawer()
                refreshFavorites()
                refreshDock()
            }
        }
    }

    /** Primeira execução: favoritos populares (como na referência) e dock Telefone/Mensagens/Câmera. */
    private fun initDefaults() {
        if (apps.isEmpty()) return
        if (!prefs.dockInit) prefs.dock = Prefs.DOCK_DEFAULT
        if (!prefs.favInit) {
            if (prefs.favorites.isEmpty()) {
                val prefer = listOf(
                    "com.google.android.youtube", "com.instagram.android", "com.discord", "com.android.vending",
                    "com.whatsapp", "com.android.chrome", "com.spotify.music", "com.zhiliaoapp.musically",
                    "com.google.android.gm", "com.google.android.apps.maps", "com.google.android.apps.photos",
                    "org.telegram.messenger", "com.netflix.mediaclient", "com.facebook.katana"
                )
                val picked = ArrayList<String>()
                for (p in prefer) {
                    val a = apps.firstOrNull { it.packageName == p }
                    if (a != null) picked.add(a.key)
                }
                if (picked.size < 8) {
                    for (a in apps) {
                        if (picked.size >= 8) break
                        if (a.key !in picked) picked.add(a.key)
                    }
                }
                prefs.favorites = picked.take(12)
            }
            prefs.markFavInit()
        }
    }

    private fun effectiveCategory(a: AppInfo): String? = prefs.categoryOf(a.key) ?: a.autoCategory

    private fun refreshDrawer() {
        if (!::adapter.isInitialized) return
        val q = searchInput.text.toString().normalized().trim()
        val list: List<AppInfo> = if (q.isNotEmpty()) {
            apps.filter { it.search.contains(q) }
        } else if (filter == FILTER_ALL) {
            apps
        } else {
            apps.filter { effectiveCategory(it) == filter }
        }
        adapter.submit(list, prefs.letterHeaders && q.isEmpty())
        alphaIndex.visibility = if (q.isEmpty()) View.VISIBLE else View.GONE
        if (list.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            emptyView.text = when {
                q.isNotEmpty() -> "Nenhum app encontrado.\nToque para pesquisar “${searchInput.text.toString().trim()}” na web"
                filter != FILTER_ALL -> "Nenhum app em “$filter”.\nSegure um app e escolha “Categoria…”."
                else -> "Carregando aplicativos…"
            }
        } else {
            emptyView.visibility = View.GONE
        }
    }

    private fun scrollToLetter(letter: Char) {
        val rows = adapter.rows
        var pos = -1
        for (i in rows.indices) {
            val r = rows[i]
            if (r is Row.App) {
                val c = r.info.search.firstOrNull()?.uppercaseChar() ?: continue
                if (c >= letter) { pos = i; break }
            }
        }
        if (pos == -1) pos = rows.indexOfLast { it is Row.App }
        if (pos >= 0) (recycler.layoutManager as? GridLayoutManager)?.scrollToPositionWithOffset(pos, 0)
    }

    private fun rebuildTabs() {
        tabRow.removeAllViews()
        tabRow.addView(makeTab("Tudo", filter == FILTER_ALL, { setFilter(FILTER_ALL) }, null))
        for (c in AppRepository.AUTO_CATEGORIES) {
            tabRow.addView(makeTab(c, filter == c, { setFilter(c) }, null))
        }
        for (c in prefs.categories) {
            tabRow.addView(makeTab(c, filter == c, { setFilter(c) }, { confirmDeleteCategory(c) }))
        }
        tabRow.addView(makeTab("＋", false, {
            Dialogs.promptText(this, "Nova categoria", "Nome da categoria") { n ->
                prefs.addCategory(n)
                rebuildTabs()
            }
        }, null))
    }

    /** Aba de texto com sublinhado na selecionada (estilo da referência). */
    private fun makeTab(text: String, selected: Boolean, onClick: () -> Unit, onLong: (() -> Unit)?): View {
        val txt = themeColor(android.R.attr.textColorPrimary)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 15f
        tv.setPadding(dpi(14), dpi(10), dpi(14), dpi(6))
        tv.setTextColor(if (selected) txt else ColorUtils.setAlphaComponent(txt, 150))
        tv.typeface = android.graphics.Typeface.create(
            if (selected) "sans-serif-medium" else "sans-serif", android.graphics.Typeface.NORMAL
        )
        col.addView(tv)
        val line = View(this)
        line.setBackgroundColor(if (selected) txt else Color.TRANSPARENT)
        col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(2)))
        col.setOnClickListener { onClick() }
        if (onLong != null) col.setOnLongClickListener { onLong(); true }
        return col
    }

    private fun setFilter(f: String) {
        filter = f
        rebuildTabs()
        refreshDrawer()
        recycler.scrollToPosition(0)
    }

    private fun confirmDeleteCategory(name: String) {
        AlertDialog.Builder(this)
            .setMessage("Excluir a categoria “$name”? Os apps continuam instalados.")
            .setPositiveButton("Excluir") { _, _ ->
                prefs.removeCategory(name)
                if (filter == name) filter = FILTER_ALL
                rebuildTabs()
                refreshDrawer()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- favoritos (páginas) e dock

    private fun refreshFavorites() {
        if (!::favAdapter.isInitialized) return
        if (!prefs.showFavs) {
            favPager.visibility = View.GONE
            favHint.visibility = View.GONE
            dots.visibility = View.GONE
            return
        }
        val txt = themeColor(android.R.attr.textColorPrimary)
        val favs = prefs.favorites.mapNotNull { k -> apps.firstOrNull { it.key == k } }
        favAdapter.iconPx = dpi(prefs.iconSize)
        favAdapter.showLabels = prefs.showLabels
        favAdapter.pressScale = prefs.pressScale
        favAdapter.textColor = txt
        if (favs.isEmpty()) {
            favAdapter.submit(emptyList())
            favPager.visibility = View.GONE
            dots.visibility = View.GONE
            favHint.visibility = if (apps.isNotEmpty()) View.VISIBLE else View.GONE
            return
        }
        favHint.visibility = View.GONE
        favPager.visibility = View.VISIBLE
        val rowH = dpi(prefs.iconSize) + if (prefs.showLabels) dpi(36) else dpi(20)
        val lp = favPager.layoutParams
        lp.height = rowH * 2
        favPager.layoutParams = lp
        favAdapter.submit(favs)
        updateDots(favPager.currentItem)
    }

    private fun updateDots(selected: Int) {
        dots.removeAllViews()
        val n = if (::favAdapter.isInitialized) favAdapter.itemCount else 0
        if (n < 2 || favPager.visibility != View.VISIBLE) {
            dots.visibility = View.INVISIBLE
            return
        }
        dots.visibility = View.VISIBLE
        val txt = themeColor(android.R.attr.textColorPrimary)
        for (i in 0 until n) {
            val d = View(this)
            d.background = Glass.fill(this, if (i == selected) txt else ColorUtils.setAlphaComponent(txt, 90), 4f)
            val lp = LinearLayout.LayoutParams(dpi(6), dpi(6))
            lp.marginStart = dpi(3)
            lp.marginEnd = dpi(3)
            dots.addView(d, lp)
        }
    }

    private fun specialSpec(key: String): Triple<Int, Int, String>? = when (key) {
        Prefs.KEY_DIAL -> Triple(R.drawable.ic_phone, Color.parseColor("#1D1D20"), "Telefone")
        Prefs.KEY_SMS -> Triple(R.drawable.ic_message, Color.parseColor("#12306B"), "Mensagens")
        Prefs.KEY_CAMERA -> Triple(R.drawable.ic_camera, Color.parseColor("#1D1D20"), "Câmera")
        else -> null
    }

    private fun launchSpecial(key: String) {
        val i: Intent = when (key) {
            Prefs.KEY_DIAL -> Intent(Intent.ACTION_DIAL)
            Prefs.KEY_SMS -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
            else -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "App não encontrado neste aparelho", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dockTile(iconRes: Int, bg: Int): FrameLayout {
        val cell = FrameLayout(this)
        val tile = FrameLayout(this)
        val shape = GradientDrawable()
        shape.cornerRadius = dp(18f)
        shape.setColor(bg)
        shape.setStroke(dpi(1), Color.argb(70, 255, 255, 255))
        tile.background = shape
        val iv = ImageView(this)
        iv.setImageResource(iconRes)
        iv.imageTintList = ColorStateList.valueOf(Color.WHITE)
        tile.addView(iv, FrameLayout.LayoutParams(dpi(28), dpi(28), Gravity.CENTER))
        cell.addView(tile, FrameLayout.LayoutParams(dpi(56), dpi(56), Gravity.CENTER))
        return cell
    }

    private fun refreshDock() {
        dock.removeAllViews()
        for (key in prefs.dock.take(Prefs.MAX_DOCK)) {
            val spec = specialSpec(key)
            val cell: FrameLayout
            if (spec != null) {
                cell = dockTile(spec.first, spec.second)
                cell.contentDescription = spec.third
                cell.setOnClickListener { launchSpecial(key) }
            } else {
                val a = apps.firstOrNull { it.key == key } ?: continue
                cell = FrameLayout(this)
                val size = dpi(54)
                val iv = ImageView(this)
                iv.contentDescription = a.label
                loader.load(a, size, iv)
                cell.addView(iv, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
                cell.setOnClickListener { launchApp(a, iv) }
            }
            cell.setOnLongClickListener {
                prefs.toggleDock(key)
                refreshDock()
                Toast.makeText(this, "Removido do dock (restaure em Configurações > Tela inicial)", Toast.LENGTH_LONG).show()
                true
            }
            pressable(cell)
            dock.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        // botão da gaveta (sempre presente)
        val btn = dockTile(R.drawable.ic_apps, Color.parseColor("#1D1D20"))
        btn.contentDescription = "Abrir gaveta de aplicativos"
        btn.setOnClickListener { openDrawer() }
        pressable(btn)
        dock.addView(btn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
    }

    private fun launchApp(app: AppInfo, v: View) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts: Bundle? = when (prefs.launchAnim) {
            "zoom" -> ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()
            "reveal" -> ActivityOptions.makeClipRevealAnimation(v, 0, 0, v.width, v.height).toBundle()
            "fade" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
            else -> null
        }
        try {
            startActivity(intent, opts)
            if (drawerOpen) root.postDelayed({ closeDrawer(false) }, 450)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(a: AppInfo, anchor: View) {
        val pm = PopupMenu(this, anchor)
        val fav = a.key in prefs.favorites
        val inDock = a.key in prefs.dock
        pm.menu.add(0, 1, 0, if (fav) "Remover dos favoritos" else "Adicionar aos favoritos")
        pm.menu.add(0, 5, 1, if (inDock) "Remover do dock" else "Adicionar ao dock")
        pm.menu.add(0, 2, 2, "Categoria…")
        pm.menu.add(0, 3, 3, "Informações do app")
        pm.menu.add(0, 4, 4, "Desinstalar")
        pm.setOnMenuItemClickListener { item ->
            try {
                when (item.itemId) {
                    1 -> {
                        if (!fav && prefs.favorites.size >= Prefs.MAX_FAVS) {
                            Toast.makeText(this, "Limite de ${Prefs.MAX_FAVS} favoritos atingido", Toast.LENGTH_SHORT).show()
                        } else {
                            prefs.toggleFavorite(a.key)
                            refreshFavorites()
                        }
                    }
                    5 -> {
                        if (!inDock && prefs.dock.size >= Prefs.MAX_DOCK) {
                            Toast.makeText(this, "O dock comporta ${Prefs.MAX_DOCK} apps", Toast.LENGTH_SHORT).show()
                        } else {
                            prefs.toggleDock(a.key)
                            refreshDock()
                        }
                    }
                    2 -> chooseCategory(a)
                    3 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}"))
                    )
                    4 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.packageName}")))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Ação indisponível para este app", Toast.LENGTH_SHORT).show()
            }
            true
        }
        pm.show()
    }

    private fun chooseCategory(a: AppInfo) {
        val cats = prefs.categories
        val items = ArrayList<String>()
        items.add("Automática")
        items.addAll(cats)
        items.add("＋ Nova categoria…")
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(items.toTypedArray()) { _, i ->
                when {
                    i == 0 -> prefs.setCategory(a.key, null)
                    i == items.size - 1 -> Dialogs.promptText(this, "Nova categoria", "Nome da categoria") { n ->
                        prefs.addCategory(n)
                        prefs.setCategory(a.key, n)
                        rebuildTabs()
                        refreshDrawer()
                    }
                    else -> prefs.setCategory(a.key, cats[i - 1])
                }
                rebuildTabs()
                refreshDrawer()
            }
            .show()
    }

    private fun webSearch(q: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Nenhum navegador disponível", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSettings() {
        SettingsActivity.open(this, "root")
    }

    private fun showHomeMenu() {
        val items = arrayOf("Adicionar widget", "Remover widget", "Alterar papel de parede", "Configurações do Nexus")
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showWidgetPicker()
                    1 -> showRemoveWidget()
                    2 -> wallpaperPicker.launch("image/*")
                    3 -> openSettings()
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- gaveta: abrir / fechar

    private fun blurTarget(): Float {
        val r = prefs.blurRadius.toFloat()
        return if (prefs.drawerAnim == "blur") maxOf(r, 30f) else r
    }

    private fun openDrawer(focusSearch: Boolean = false) {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        val d = prefs.dur(340)
        drawerPanel.animate().cancel()
        drawerPanel.alpha = 0f
        drawerPanel.translationY = 0f
        drawerPanel.scaleX = 1f
        drawerPanel.scaleY = 1f
        drawer.alpha = 0f
        when (prefs.drawerAnim) {
            "zoom" -> { drawerPanel.scaleX = 0.9f; drawerPanel.scaleY = 0.9f }
            "fade", "blur" -> {}
            else -> drawerPanel.translationY = root.height * 0.15f
        }
        drawer.animate().alpha(1f).setDuration(d).start()
        drawerPanel.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(d).setInterpolator(DecelerateInterpolator(1.8f)).start()
        homeLayer.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(d).start()
        animateBlur(blurTarget(), d)
        if (focusSearch || prefs.autoFocus) {
            searchInput.requestFocus()
            searchInput.postDelayed({
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
            }, 200)
        }
    }

    private fun closeDrawer(animated: Boolean = true) {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.setText("")
        searchInput.clearFocus()
        recycler.scrollToPosition(0)
        if (!animated) {
            drawerPanel.animate().cancel()
            drawer.animate().cancel()
            homeLayer.animate().cancel()
            drawer.visibility = View.GONE
            drawer.alpha = 1f
            homeLayer.alpha = 1f
            homeLayer.scaleX = 1f
            homeLayer.scaleY = 1f
            blurAnim?.cancel()
            if (Build.VERSION.SDK_INT >= 31) applyBlur(0f)
            return
        }
        val d = prefs.dur(260)
        val anim = drawerPanel.animate().alpha(0f).setDuration(d)
        when (prefs.drawerAnim) {
            "zoom" -> anim.scaleX(0.92f).scaleY(0.92f)
            "fade", "blur" -> {}
            else -> anim.translationY(root.height * 0.1f)
        }
        anim.start()
        drawer.animate().alpha(0f).setDuration(d).withEndAction {
            if (!drawerOpen) {
                drawer.visibility = View.GONE
                drawer.alpha = 1f
            }
        }.start()
        homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(d).start()
        animateBlur(0f, d)
    }

    private fun animateBlur(to: Float, d: Long) {
        blurAnim?.cancel()
        if (Build.VERSION.SDK_INT < 31) return
        val allowed = prefs.blurTransitions || prefs.drawerAnim == "blur"
        if (!allowed || (to == 0f && currentBlur == 0f)) {
            applyBlur(0f)
            return
        }
        blurAnim = ValueAnimator.ofFloat(currentBlur, to).setDuration(d).apply {
            addUpdateListener { applyBlur(it.animatedValue as Float) }
            start()
        }
    }

    /** Blur do conteúdo da home (RenderEffect) e do fundo/papel de parede (blur de janela), Android 12+. */
    @RequiresApi(31)
    private fun applyBlur(r: Float) {
        currentBlur = r
        homeLayer.setRenderEffect(
            if (r > 0.5f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null
        )
        window.setBackgroundBlurRadius(r.toInt())
    }

    // ---------------------------------------------------------------- widgets reais (AppWidgetHost)

    private fun showWidgetPicker() {
        val providers = awm.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "Nenhum widget disponível neste aparelho", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = providers.map { p ->
            val app = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(p.provider.packageName, 0)).toString()
            } catch (e: Exception) {
                p.provider.packageName
            }
            "$app · ${p.loadLabel(packageManager)}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolher widget")
            .setItems(labels) { _, i -> bindWidget(providers[i]) }
            .show()
    }

    private fun bindWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrAdd(id, info)
        } else {
            pendingWidgetId = id
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                widgetHost.deleteAppWidgetId(id)
                pendingWidgetId = -1
                Toast.makeText(this, "Este aparelho não permitiu vincular o widget", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun configureOrAdd(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            pendingWidgetId = id
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                finishAddWidget(id)
                pendingWidgetId = -1
            }
        } else {
            finishAddWidget(id)
        }
    }

    private fun finishAddWidget(id: Int) {
        prefs.widgetIds = prefs.widgetIds + id
        prefs.sp.edit().putBoolean("show_widget_area", true).apply()
        restoreWidgets(true)
    }

    @Deprecated("Necessário para AppWidgetHost")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_BIND && requestCode != REQ_CONFIG) return
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
        if (resultCode != RESULT_OK) {
            if (id != -1) widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
            return
        }
        if (requestCode == REQ_BIND) {
            val info = awm.getAppWidgetInfo(id)
            if (info != null) configureOrAdd(id, info)
        } else {
            finishAddWidget(id)
            pendingWidgetId = -1
        }
    }

    private fun restoreWidgets(force: Boolean = false) {
        val saved = prefs.widgetIds
        val ids = saved.filter { awm.getAppWidgetInfo(it) != null }
        if (ids != saved) prefs.widgetIds = ids
        widgetPanel.visibility = if (prefs.showWidgetArea && ids.isNotEmpty()) View.VISIBLE else View.GONE
        val sig = ids.joinToString(",") + "|" + prefs.widgetHeight
        if (!force && sig == lastWidgetSig) return
        lastWidgetSig = sig

        widgetRow.removeAllViews()
        val density = resources.displayMetrics.density
        val hPx = dpi(prefs.widgetHeight)
        val wPx = (resources.displayMetrics.widthPixels * 0.8f).toInt()
        for (id in ids) {
            val info = awm.getAppWidgetInfo(id) ?: continue
            val hv: AppWidgetHostView = widgetHost.createView(this, id, info)
            hv.setOnLongClickListener { confirmRemoveWidget(id); true }
            val lp = LinearLayout.LayoutParams(
                if (ids.size == 1) ViewGroup.LayoutParams.MATCH_PARENT else wPx, hPx
            )
            widgetRow.addView(hv, lp)
            hv.post {
                val w = (wPx / density).toInt()
                val h = (hPx / density).toInt()
                hv.updateAppWidgetSize(null, w, h, w, h)
            }
        }
    }

    private fun confirmRemoveWidget(id: Int) {
        AlertDialog.Builder(this)
            .setMessage("Remover este widget da tela inicial?")
            .setPositiveButton("Remover") { _, _ -> removeWidget(id) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showRemoveWidget() {
        val ids = prefs.widgetIds
        if (ids.isEmpty()) {
            Toast.makeText(this, "Nenhum widget do Android adicionado", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = ids.map { awm.getAppWidgetInfo(it)?.loadLabel(packageManager) ?: "Widget $it" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Remover qual widget?")
            .setItems(labels) { _, i -> removeWidget(ids[i]) }
            .show()
    }

    private fun removeWidget(id: Int) {
        try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) { }
        prefs.widgetIds = prefs.widgetIds - id
        restoreWidgets(true)
    }
}
