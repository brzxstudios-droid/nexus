package com.nexus.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** Suporte a pacotes de ícones no padrão Nova/ADW/GO (appfilter.xml). */
class IconPackManager(private val ctx: Context) {
    data class Pack(val pkg: String, val label: String)

    private val maps = HashMap<String, Map<String, String>>()

    companion object {
        private val ACTIONS = listOf(
            "org.adw.launcher.THEMES",
            "com.novalauncher.THEME",
            "com.gau.go.launcherex.theme"
        )
    }

    fun list(): List<Pack> {
        val pm = ctx.packageManager
        val out = LinkedHashMap<String, Pack>()
        for (action in ACTIONS) {
            for (ri in pm.queryIntentActivities(Intent(action), 0)) {
                val p = ri.activityInfo.packageName
                if (!out.containsKey(p)) {
                    val label = try {
                        ri.activityInfo.applicationInfo.loadLabel(pm).toString()
                    } catch (e: Exception) {
                        p
                    }
                    out[p] = Pack(p, label)
                }
            }
        }
        return out.values.sortedBy { it.label.lowercase() }
    }

    fun iconFor(pack: String, c: ComponentName): Drawable? {
        if (pack == "default" || pack.isEmpty()) return null
        val map = synchronized(maps) { maps.getOrPut(pack) { parse(pack) } }
        val name = map[c.flattenToString()] ?: map[c.packageName + "/" + c.className] ?: return null
        return try {
            val res = ctx.packageManager.getResourcesForApplication(pack)
            val id = res.getIdentifier(name, "drawable", pack)
            if (id == 0) null else ResourcesCompat.getDrawable(res, id, null)
        } catch (e: Exception) {
            null
        }
    }

    private fun parse(pack: String): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            val res = ctx.packageManager.getResourcesForApplication(pack)
            val xmlId = res.getIdentifier("appfilter", "xml", pack)
            val parser: XmlPullParser = if (xmlId != 0) {
                res.getXml(xmlId)
            } else {
                XmlPullParserFactory.newInstance().newPullParser().also {
                    it.setInput(res.assets.open("appfilter.xml"), null)
                }
            }
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null && comp.startsWith("ComponentInfo{")) {
                        map[comp.substringAfter("{").substringBefore("}")] = dr
                    }
                }
                ev = parser.next()
            }
        } catch (e: Exception) {
            // pacote sem appfilter legível: usa ícones padrão
        }
        return map
    }
}
