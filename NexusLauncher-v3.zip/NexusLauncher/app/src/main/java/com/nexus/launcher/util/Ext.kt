package com.nexus.launcher.util

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import java.text.Normalizer
import kotlin.math.roundToInt

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dp(v: Int): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = dp(v).roundToInt()
fun Context.dpi(v: Int): Int = dp(v).roundToInt()

fun Context.isNight(): Boolean =
    (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

fun Context.themeColor(attr: Int): Int {
    val a = obtainStyledAttributes(intArrayOf(attr))
    try {
        return a.getColor(0, Color.WHITE)
    } finally {
        a.recycle()
    }
}

private val DIACRITICS = Regex("\\p{InCombiningDiacriticalMarks}+")

/** Minúsculo e sem acentos, para busca e ordenação por letra. */
fun String.normalized(): String =
    Normalizer.normalize(this, Normalizer.Form.NFD).replace(DIACRITICS, "").lowercase()
